import js from '@eslint/js';
import globals from 'globals';

export default [
    js.configs.recommended,
    {
        languageOptions: {
            ecmaVersion: 2022,
            sourceType: 'module',
            globals: {
                ...globals.browser,
                ...globals.node,
                Chart: 'readonly',
                bootstrap: 'readonly',
                initSqlJs: 'readonly',
                clients: 'readonly',
                FitnessScore: 'readonly',
                FitLogicCharts: 'readonly',
                RuleEngine: 'readonly',
                WorkoutGenerator: 'readonly',
                fitlogicDB: 'readonly'
            }
        },
        rules: {
            'no-unused-vars': 'warn',
            'no-console': 'warn',
            'no-undef': 'off',
            'no-var': 'error',
            'no-undef': 'error'
        }
    },
    {
        ignores: ['**/*.min.js']
    }
];