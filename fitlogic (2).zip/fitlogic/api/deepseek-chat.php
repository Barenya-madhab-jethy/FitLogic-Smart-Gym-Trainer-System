<?php
// DeepSeek API Integration
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);
$message = $input['message'] ?? '';
$context = $input['context'] ?? [];

if (empty($message)) {
    http_response_code(400);
    echo json_encode(['error' => 'Message is required']);
    exit();
}

// DeepSeek API configuration
$apiKey = 'sk-9877f03ff3b34ffb8efbb63f12129c51';
$apiUrl = 'https://api.deepseek.com/v1/chat/completions';

// Prepare the system prompt with context
$systemPrompt = "You are FitLogic AI, a fitness assistant for a smart gym trainer system. ";
$systemPrompt .= "You help users with workout decisions, nutrition advice, recovery tips, and motivation. ";
$systemPrompt .= "Keep responses concise, practical, and focused on fitness. ";

if (!empty($context)) {
    $systemPrompt .= "Current user context: ";
    $systemPrompt .= "Goal: " . ($context['goal'] ?? 'Not set') . ". ";
    $systemPrompt .= "Recent workouts: " . ($context['workoutCount'] ?? 0) . " in last 7 days. ";
    $systemPrompt .= "Fitness score: " . ($context['score'] ?? 0) . "/100. ";
}

// Prepare the request payload
$payload = [
    'model' => 'deepseek-chat',
    'messages' => [
        [
            'role' => 'system',
            'content' => $systemPrompt
        ],
        [
            'role' => 'user',
            'content' => $message
        ]
    ],
    'temperature' => 0.7,
    'max_tokens' => 500,
    'top_p' => 0.9,
    'frequency_penalty' => 0.3,
    'presence_penalty' => 0.3
];

// Initialize cURL
$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $apiKey
]);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // For development only

// Execute request
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

if ($error) {
    http_response_code(500);
    echo json_encode(['error' => 'API request failed: ' . $error]);
    exit();
}

if ($httpCode !== 200) {
    http_response_code($httpCode);
    echo $response;
    exit();
}

// Parse and return response
$data = json_decode($response, true);

if (isset($data['choices'][0]['message']['content'])) {
    echo json_encode([
        'success' => true,
        'response' => $data['choices'][0]['message']['content']
    ]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Invalid API response format']);
}

// Log the interaction (optional)
$logEntry = date('Y-m-d H:i:s') . " - Message: $message - Response: " . ($data['choices'][0]['message']['content'] ?? 'N/A') . "\n";
file_put_contents('chat_log.txt', $logEntry, FILE_APPEND);
?>