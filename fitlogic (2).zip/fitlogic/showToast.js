function showToast(message, type = 'success') {
    // Remove existing toasts
    document.querySelectorAll('.sync-toast').forEach(t => t.remove());

    const toast = document.createElement('div');
    toast.className = `sync-toast ${type}`;

    let icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'info') icon = 'info-circle';

    toast.innerHTML = `<i class="fas fa-${icon}"></i><span>${message}</span>`;
    document.body.appendChild(toast);

    // Auto remove
    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Make global
window.showToast = showToast;