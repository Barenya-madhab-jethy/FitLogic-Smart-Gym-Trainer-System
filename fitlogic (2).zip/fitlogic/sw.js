// Service Worker for Offline-First Architecture
const CACHE_NAME = 'fitlogic-v1';
const API_CACHE = 'fitlogic-api-v1';

const urlsToCache = [
    '/',
    '/index.html',
    '/dashboard.html',
    '/workout.html',
    '/nutrition.html',
    '/history.html',
    '/injury-mode.html',
    '/css/style.css',
    '/css/animations.css',
    '/css/responsive.css',
    '/js/main.js',
    '/js/rule-engine.js',
    '/js/workout-generator.js',
    '/js/fitness-score.js',
    '/js/charts.js',
    '/js/chatbot.js',
    '/js/offline-sync.js',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js',
    'https://cdn.jsdelivr.net/npm/chart.js'
];

// Install event
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
        .then(cache => {
            console.log('Opened cache');
            return cache.addAll(urlsToCache);
        })
    );
});

// Activate event
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheName !== CACHE_NAME && cacheName !== API_CACHE) {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});

// Fetch event - Network first, then cache
self.addEventListener('fetch', event => {
    const url = new URL(event.request.url);

    // API requests - Network first with cache fallback
    if (url.pathname.startsWith('/api/')) {
        event.respondWith(
            fetch(event.request)
            .then(response => {
                const clone = response.clone();
                caches.open(API_CACHE).then(cache => {
                    cache.put(event.request, clone);
                });
                return response;
            })
            .catch(() => {
                return caches.match(event.request);
            })
        );
    }
    // Static assets - Cache first
    else {
        event.respondWith(
            caches.match(event.request)
            .then(response => {
                if (response) {
                    return response;
                }

                return fetch(event.request).then(response => {
                    // Check if valid response
                    if (!response || response.status !== 200 || response.type !== 'basic') {
                        return response;
                    }

                    const clone = response.clone();
                    caches.open(CACHE_NAME).then(cache => {
                        cache.put(event.request, clone);
                    });

                    return response;
                });
            })
        );
    }
});

// Background sync for offline actions
self.addEventListener('sync', event => {
    if (event.tag === 'sync-workouts') {
        event.waitUntil(syncWorkouts());
    } else if (event.tag === 'sync-nutrition') {
        event.waitUntil(syncNutrition());
    }
});

// Sync workouts
async function syncWorkouts() {
    const db = await openDB();
    const tx = db.transaction('offlineWorkouts', 'readonly');
    const store = tx.objectStore('offlineWorkouts');
    const workouts = await store.getAll();

    return Promise.all(workouts.map(async workout => {
        try {
            const response = await fetch('/api/sync-workout', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(workout)
            });

            if (response.ok) {
                const deleteTx = db.transaction('offlineWorkouts', 'readwrite');
                const deleteStore = deleteTx.objectStore('offlineWorkouts');
                await deleteStore.delete(workout.id);
            }
        } catch (error) {
            console.error('Sync failed:', error);
        }
    }));
}

// Sync nutrition
async function syncNutrition() {
    const db = await openDB();
    const tx = db.transaction('offlineNutrition', 'readonly');
    const store = tx.objectStore('offlineNutrition');
    const meals = await store.getAll();

    return Promise.all(meals.map(async meal => {
        try {
            const response = await fetch('/api/sync-meal', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(meal)
            });

            if (response.ok) {
                const deleteTx = db.transaction('offlineNutrition', 'readwrite');
                const deleteStore = deleteTx.objectStore('offlineNutrition');
                await deleteStore.delete(meal.id);
            }
        } catch (error) {
            console.error('Sync failed:', error);
        }
    }));
}

// Open IndexedDB
function openDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('FitLogicDB', 1);

        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);

        request.onupgradeneeded = event => {
            const db = event.target.result;

            if (!db.objectStoreNames.contains('offlineWorkouts')) {
                db.createObjectStore('offlineWorkouts', { keyPath: 'id' });
            }

            if (!db.objectStoreNames.contains('offlineNutrition')) {
                db.createObjectStore('offlineNutrition', { keyPath: 'id' });
            }

            if (!db.objectStoreNames.contains('userSettings')) {
                db.createObjectStore('userSettings');
            }
        };
    });
}

// Push notification handler
self.addEventListener('push', event => {
    const data = event.data.json();

    const options = {
        body: data.body,
        icon: '/assets/icons/icon-192.png',
        badge: '/assets/icons/badge.png',
        vibrate: [200, 100, 200],
        data: {
            url: data.url
        }
    };

    event.waitUntil(
        self.registration.showNotification(data.title, options)
    );
});

// Notification click handler
self.addEventListener('notificationclick', event => {
    event.notification.close();

    event.waitUntil(
        clients.openWindow(event.notification.data.url)
    );
});