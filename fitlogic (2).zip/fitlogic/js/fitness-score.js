// Fitness Score Calculation Engine
class FitnessScore {
    constructor() {
        this.score = 0;
        this.components = {
            consistency: 0,
            strength: 0,
            recovery: 0,
            balance: 0,
            nutrition: 0
        };
    }

    // Calculate overall fitness score
    calculateScore(userData) {
        this.components.consistency = this.calculateConsistency(userData.workouts);
        this.components.strength = this.calculateStrength(userData.workouts);
        this.components.recovery = this.calculateRecovery(userData);
        this.components.balance = this.calculateMuscleBalance(userData.workouts);
        this.components.nutrition = this.calculateNutrition(userData.nutrition);

        // Weighted average
        this.score = (
            this.components.consistency * 0.25 +
            this.components.strength * 0.25 +
            this.components.recovery * 0.2 +
            this.components.balance * 0.15 +
            this.components.nutrition * 0.15
        );

        return Math.round(this.score);
    }

    // Calculate consistency score (0-100)
    calculateConsistency(workouts) {
        if (!workouts || workouts.length === 0) return 0;

        const now = Date.now();
        const thirtyDaysAgo = now - (30 * 24 * 60 * 60 * 1000);

        // Count workouts in last 30 days
        const recentWorkouts = workouts.filter(w =>
            new Date(w.date).getTime() > thirtyDaysAgo
        );

        // Expected workouts (every other day = 15)
        const expectedWorkouts = 15;
        const actualWorkouts = recentWorkouts.length;

        let consistencyScore = (actualWorkouts / expectedWorkouts) * 100;

        // Bonus for streaks
        const streak = this.calculateStreak(workouts);
        if (streak > 7) {
            consistencyScore += 10;
        } else if (streak > 14) {
            consistencyScore += 20;
        } else if (streak > 30) {
            consistencyScore += 30;
        }

        return Math.min(100, consistencyScore);
    }

    // Calculate strength score (0-100)
    calculateStrength(workouts) {
        if (!workouts || workouts.length < 2) return 50;

        // Sort by date
        const sorted = [...workouts].sort((a, b) =>
            new Date(a.date) - new Date(b.date)
        );

        // Calculate strength improvement
        const firstWorkout = sorted[0];
        const lastWorkout = sorted[sorted.length - 1];

        // Get total volume for first and last
        const firstVolume = this.calculateWorkoutVolume(firstWorkout);
        const lastVolume = this.calculateWorkoutVolume(lastWorkout);

        if (firstVolume === 0) return 50;

        const improvement = ((lastVolume - firstVolume) / firstVolume) * 100;

        // Base score
        let strengthScore = 50 + improvement;

        // Bonus for progressive overload
        const progressiveOverload = this.checkProgressiveOverload(sorted);
        strengthScore += progressiveOverload * 10;

        return Math.min(100, Math.max(0, strengthScore));
    }

    // Calculate workout volume
    calculateWorkoutVolume(workout) {
        if (!workout || !workout.mainExercises) return 0;

        return workout.mainExercises.reduce((total, ex) => {
            // Estimate weight * reps * sets
            const weight = ex.weight || 50; // Default if not recorded
            const reps = parseInt(ex.reps) || 10;
            return total + (weight * reps * ex.sets);
        }, 0);
    }

    // Check for progressive overload
    checkProgressiveOverload(workouts) {
        if (workouts.length < 3) return 0;

        let overloadCount = 0;
        const lastThree = workouts.slice(-3);

        for (let i = 1; i < lastThree.length; i++) {
            const prevVolume = this.calculateWorkoutVolume(lastThree[i - 1]);
            const currVolume = this.calculateWorkoutVolume(lastThree[i]);

            if (currVolume > prevVolume) {
                overloadCount++;
            }
        }

        return overloadCount / 2; // 0, 0.5, or 1
    }

    // Calculate recovery score (0-100)
    calculateRecovery(userData) {
        let recoveryScore = 70; // Base score

        // Sleep factor
        if (userData.sleep && userData.sleep.length > 0) {
            const avgSleep = userData.sleep.reduce((sum, s) => sum + s, 0) / userData.sleep.length;
            recoveryScore += (avgSleep - 7) * 10; // +10 for each hour above 7, -10 for each below
        }

        // Rest days factor
        if (userData.workouts) {
            const totalDays = 30;
            const workoutDays = userData.workouts.length;
            const restDays = totalDays - workoutDays;

            if (restDays < 4) {
                recoveryScore -= 20; // Not enough rest
            } else if (restDays > 10) {
                recoveryScore -= 10; // Too much rest
            }
        }

        // Injury factor
        if (userData.injury && userData.injury.active) {
            recoveryScore *= 0.7; // 30% reduction
        }

        return Math.min(100, Math.max(0, recoveryScore));
    }

    // Calculate muscle balance score (0-100)
    calculateMuscleBalance(workouts) {
        if (!workouts || workouts.length === 0) return 70;

        const muscleGroups = ['chest', 'back', 'legs', 'shoulders', 'arms', 'core'];
        const counts = {};

        muscleGroups.forEach(m => counts[m] = 0);

        // Count exercises per muscle group
        workouts.forEach(workout => {
            if (workout.mainExercises) {
                workout.mainExercises.forEach(ex => {
                    if (counts[ex.muscleGroup] !== undefined) {
                        counts[ex.muscleGroup]++;
                    }
                });
            }
        });

        // Calculate balance score
        const values = Object.values(counts);
        const max = Math.max(...values);
        const min = Math.min(...values);

        if (max === 0) return 70;

        const ratio = min / max;
        let balanceScore = ratio * 100;

        // Penalty for completely missing groups
        const missingGroups = muscleGroups.filter(m => counts[m] === 0).length;
        balanceScore -= missingGroups * 5;

        return Math.max(0, balanceScore);
    }

    // Calculate nutrition score (0-100)
    calculateNutrition(nutrition) {
        if (!nutrition || !nutrition.meals || nutrition.meals.length === 0) {
            return 50; // Default if no data
        }

        let nutritionScore = 70; // Base score

        // Check calorie balance
        const calorieBalance = this.checkCalorieBalance(nutrition);
        nutritionScore += calorieBalance * 20;

        // Check macro balance
        const macroBalance = this.checkMacroBalance(nutrition);
        nutritionScore += macroBalance * 20;

        // Check meal frequency
        const mealFrequency = this.checkMealFrequency(nutrition);
        nutritionScore += mealFrequency * 10;

        return Math.min(100, Math.max(0, nutritionScore));
    }

    // Check calorie balance
    checkCalorieBalance(nutrition) {
        const today = new Date().toISOString().split('T')[0];
        const todayMeals = nutrition.meals.filter(m => m.date === today);

        const totalCalories = todayMeals.reduce((sum, m) => sum + m.calories, 0);
        const targetCalories = nutrition.calorieGoal || 2400;

        const diff = Math.abs(totalCalories - targetCalories) / targetCalories;

        if (diff < 0.1) return 1; // Within 10%
        if (diff < 0.2) return 0.5; // Within 20%
        if (diff < 0.3) return 0; // Within 30%
        return -0.5; // Way off
    }

    // Check macro balance
    checkMacroBalance(nutrition) {
        const today = new Date().toISOString().split('T')[0];
        const todayMeals = nutrition.meals.filter(m => m.date === today);

        if (todayMeals.length === 0) return 0;

        const totals = todayMeals.reduce((sum, m) => ({
            protein: sum.protein + (m.protein || 0),
            carbs: sum.carbs + (m.carbs || 0),
            fats: sum.fats + (m.fats || 0)
        }), { protein: 0, carbs: 0, fats: 0 });

        const total = totals.protein * 4 + totals.carbs * 4 + totals.fats * 9;
        if (total === 0) return 0;

        // Ideal macros: 30% protein, 40% carbs, 30% fats
        const proteinPct = (totals.protein * 4) / total;
        const carbsPct = (totals.carbs * 4) / total;
        const fatsPct = (totals.fats * 9) / total;

        const proteinDiff = Math.abs(proteinPct - 0.3);
        const carbsDiff = Math.abs(carbsPct - 0.4);
        const fatsDiff = Math.abs(fatsPct - 0.3);

        const avgDiff = (proteinDiff + carbsDiff + fatsDiff) / 3;

        if (avgDiff < 0.05) return 1;
        if (avgDiff < 0.1) return 0.5;
        if (avgDiff < 0.15) return 0;
        return -0.5;
    }

    // Check meal frequency
    checkMealFrequency(nutrition) {
        const today = new Date().toISOString().split('T')[0];
        const todayMeals = nutrition.meals.filter(m => m.date === today);

        if (todayMeals.length >= 4) return 1;
        if (todayMeals.length >= 3) return 0.5;
        if (todayMeals.length >= 2) return 0;
        return -0.5;
    }

    // Calculate streak
    calculateStreak(workouts) {
        if (!workouts || workouts.length === 0) return 0;

        // Sort by date
        const sorted = [...workouts].sort((a, b) =>
            new Date(b.date) - new Date(a.date)
        );

        let streak = 1;
        let currentDate = new Date(sorted[0].date).setHours(0, 0, 0, 0);

        for (let i = 1; i < sorted.length; i++) {
            const prevDate = new Date(sorted[i - 1].date).setHours(0, 0, 0, 0);
            const currDate = new Date(sorted[i].date).setHours(0, 0, 0, 0);

            if (prevDate - currDate === 86400000) { // One day difference
                streak++;
            } else {
                break;
            }
        }

        return streak;
    }

    // Get score breakdown
    getScoreBreakdown() {
        return {
            total: this.score,
            components: this.components,
            details: {
                consistency: `${this.components.consistency.toFixed(1)}% - Based on workout frequency`,
                strength: `${this.components.strength.toFixed(1)}% - Based on strength progression`,
                recovery: `${this.components.recovery.toFixed(1)}% - Based on sleep and rest`,
                balance: `${this.components.balance.toFixed(1)}% - Based on muscle group balance`,
                nutrition: `${this.components.nutrition.toFixed(1)}% - Based on diet quality`
            }
        };
    }

    // Get score interpretation
    getScoreInterpretation() {
        if (this.score >= 90) {
            return {
                level: 'Elite',
                message: 'Excellent! You\'re in top form. Keep up the great work!',
                color: '#00ff88',
                nextGoal: 'Maintain this high standard and consider new challenges'
            };
        } else if (this.score >= 75) {
            return {
                level: 'Advanced',
                message: 'Very good! You\'re making solid progress.',
                color: '#4169e1',
                nextGoal: 'Focus on consistency to reach elite level'
            };
        } else if (this.score >= 60) {
            return {
                level: 'Intermediate',
                message: 'Good progress! There\'s room for improvement.',
                color: '#8a2be2',
                nextGoal: 'Work on consistency and try progressive overload'
            };
        } else if (this.score >= 40) {
            return {
                level: 'Beginner',
                message: 'You\'re on the right track! Keep building habits.',
                color: '#ffa500',
                nextGoal: 'Focus on showing up regularly and building routine'
            };
        } else {
            return {
                level: 'Just Started',
                message: 'Every journey begins with a single step. You\'ve taken yours!',
                color: '#ff4444',
                nextGoal: 'Start with 2-3 workouts per week to build momentum'
            };
        }
    }

    // Get recommendations based on score
    getRecommendations() {
        const recommendations = [];

        if (this.components.consistency < 50) {
            recommendations.push({
                area: 'Consistency',
                tip: 'Try to work out at least 3 times per week',
                action: 'Schedule your workouts in advance'
            });
        }

        if (this.components.strength < 50) {
            recommendations.push({
                area: 'Strength',
                tip: 'Focus on progressive overload - increase weight or reps gradually',
                action: 'Try our progressive overload calculator'
            });
        }

        if (this.components.recovery < 50) {
            recommendations.push({
                area: 'Recovery',
                tip: 'Aim for 7-8 hours of sleep and take rest days',
                action: 'Check our sleep optimization guide'
            });
        }

        if (this.components.balance < 50) {
            recommendations.push({
                area: 'Muscle Balance',
                tip: 'Don\'t neglect any muscle group - train your whole body',
                action: 'Try our balanced workout generator'
            });
        }

        if (this.components.nutrition < 50) {
            recommendations.push({
                area: 'Nutrition',
                tip: 'Track your meals and aim for balanced macros',
                action: 'Check our Indian meal suggestions'
            });
        }

        return recommendations;
    }
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FitnessScore;
}