// SQLite Database Manager using sql.js - FIXED VERSION
class FitLogicDB {
    constructor() {
        this.db = null;
        this.dbName = 'FitLogicSQLiteDB';
        this.isInitialized = false;
    }

    // Initialize the database
    async init() {
        if (this.isInitialized) return this.db;

        return new Promise((resolve, reject) => {
            const sqlJsScript = document.createElement('script');
            sqlJsScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.8.0/sql-wasm.js';
            sqlJsScript.onload = async() => {
                try {
                    await this.createDatabase();
                    this.isInitialized = true;
                    resolve(this.db);
                } catch (error) {
                    reject(error);
                }
            };
            sqlJsScript.onerror = () => {
                reject(new Error('Failed to load sql.js'));
            };
            document.head.appendChild(sqlJsScript);
        });
    }

    // Create and initialize the database
    async createDatabase() {
        const SQL = await initSqlJs({
            locateFile: file => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.8.0/${file}`
        });

        const savedDb = localStorage.getItem(this.dbName);
        if (savedDb) {
            const uint8Array = new Uint8Array(JSON.parse(savedDb));
            this.db = new SQL.Database(uint8Array);
        } else {
            this.db = new SQL.Database();
        }

        this.createTables();
        await this.migrateFromLocalStorage();
    }

    createTables() {
        // Users table
        this.db.run(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                name TEXT,
                email TEXT,
                goal TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Workouts table
        this.db.run(`
            CREATE TABLE IF NOT EXISTS workouts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER DEFAULT 1,
                date DATETIME NOT NULL,
                focus TEXT,
                intensity TEXT,
                estimated_duration INTEGER,
                warmup TEXT,
                main_exercises TEXT,
                cooldown TEXT,
                cardio TEXT,
                completed INTEGER DEFAULT 0,
                completed_at DATETIME,
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        `);

        // User settings table
        this.db.run(`
            CREATE TABLE IF NOT EXISTS user_settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER DEFAULT 1,
                \`key\` TEXT UNIQUE NOT NULL,
                value TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        `);

        // Meal logs table
        this.db.run(`
            CREATE TABLE IF NOT EXISTS meal_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER DEFAULT 1,
                date DATE NOT NULL,
                meal_type TEXT,
                name TEXT,
                calories INTEGER,
                protein REAL,
                carbs REAL,
                fats REAL,
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        `);

        // Fitness scores table
        this.db.run(`
            CREATE TABLE IF NOT EXISTS fitness_scores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER DEFAULT 1,
                score INTEGER,
                best_streak INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        `);
    }

    // Migrate data from localStorage to SQLite
    async migrateFromLocalStorage() {
        const migrationDone = localStorage.getItem('fitlogic_sqlite_migrated');
        if (migrationDone === 'true') return;

        try {
            // Migrate workouts
            const savedWorkouts = localStorage.getItem('fitlogic_workouts');
            if (savedWorkouts) {
                const workouts = JSON.parse(savedWorkouts);
                for (const workout of workouts) {
                    await this.saveWorkout(workout);
                }
            }

            // Migrate user data
            const userData = localStorage.getItem('fitlogic_user');
            if (userData) {
                const user = JSON.parse(userData);
                await this.saveUser(user);
            }

            // Migrate preferences
            const preferences = localStorage.getItem('fitlogic_preferences');
            if (preferences) {
                const prefs = JSON.parse(preferences);
                await this.saveSetting('preferences', JSON.stringify(prefs));
            }

            // Migrate fitness score
            const score = localStorage.getItem('fitlogic_score');
            if (score) {
                await this.saveSetting('fitness_score', score);
            }

            localStorage.setItem('fitlogic_sqlite_migrated', 'true');
        } catch (error) {
            // Migration error logged silently
        }
    }

    saveToStorage() {
        if (!this.db) return;
        const data = this.db.export();
        const arr = Array.from(data);
        localStorage.setItem(this.dbName, JSON.stringify(arr));
    }

    async saveWorkout(workout) {
        if (!this.db) await this.init();

        const stmt = this.db.prepare(`
            INSERT INTO workouts(
                user_id, date, focus, intensity, estimated_duration,
                warmup, main_exercises, cooldown, cardio, completed, 
                completed_at, notes
            ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.bind([
            1,
            workout.date || new Date().toISOString(),
            workout.focus || 'Full Body',
            workout.intensity || 'Moderate',
            workout.estimatedDuration || 45,
            JSON.stringify(workout.warmup || []),
            JSON.stringify(workout.mainExercises || []),
            JSON.stringify(workout.cooldown || []),
            JSON.stringify(workout.cardio || null),
            workout.completed ? 1 : 0,
            workout.completedAt || null,
            workout.notes ? JSON.stringify(workout.notes) : null
        ]);

        stmt.step();
        const result = this.db.exec('SELECT last_insert_rowid() as id');
        const insertId = result.length > 0 && result[0].values && result[0].values.length > 0 && result[0].values[0].length > 0 ? result[0].values[0][0] : 0;
        stmt.free();

        this.saveToStorage();
        await this.syncToLocalStorage('workouts');

        return insertId;
    }

    async getWorkouts(limit = 100, offset = 0) {
        if (!this.db) await this.init();

        const stmt = this.db.prepare('SELECT * FROM workouts ORDER BY date DESC LIMIT ? OFFSET ?');
        stmt.bind([limit, offset]);
        const result = stmt.getAsObject();
        stmt.free();

        return result || [];
    }

    async getWorkoutById(id) {
        if (!this.db) await this.init();

        const stmt = this.db.prepare('SELECT * FROM workouts WHERE id = ?');
        stmt.bind([id]);
        const result = stmt.getAsObject();
        stmt.free();

        if (!result) return null;

        // Parse JSON fields
        ['warmup', 'main_exercises', 'cooldown', 'cardio'].forEach(field => {
            const key = field === 'main_exercises' ? 'mainExercises' : field;
            if (result[field]) {
                try {
                    result[key] = JSON.parse(result[field]);
                    delete result[field];
                } catch (e) {
                    result[key] = result[field];
                }
            }
        });

        result.completed = !!result.completed;
        if (result.estimated_duration) {
            result.estimatedDuration = result.estimated_duration;
            delete result.estimated_duration;
        }

        return result;
    }

    async deleteWorkout(id) {
        if (!this.db) await this.init();

        this.db.run('DELETE FROM workouts WHERE id = ?', id);
        this.saveToStorage();
        await this.syncToLocalStorage('workouts');
    }

    async clearWorkouts() {
        if (!this.db) await this.init();

        this.db.run('DELETE FROM workouts');
        this.saveToStorage();
        localStorage.removeItem('fitlogic_workouts');
    }

    async getWorkoutStats() {
        if (!this.db) await this.init();

        const result = this.db.exec(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END) as completed,
                SUM(estimated_duration) as total_duration,
                COUNT(DISTINCT DATE(date)) as unique_days 
            FROM workouts
        `);

        if (!result || !result[0] || !result[0].values || !result[0].values.length) {
            return { total: 0, completed: 0, totalDuration: 0, uniqueDays: 0 };
        }

        const row = result[0].values[0];
        return {
            total: row[0] || 0,
            completed: row[1] || 0,
            totalDuration: row[2] || 0,
            uniqueDays: row[3] || 0
        };
    }

    async saveUser(user) {
        if (!this.db) await this.init();

        const existingResult = this.db.exec('SELECT id FROM users WHERE id = 1');
        if (existingResult.length > 0 && existingResult[0].values && existingResult[0].values.length > 0) {
            this.db.run(
                'UPDATE users SET name = ?, email = ?, goal = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1', [user.name || '', user.email || '', user.goal || 'General Fitness']
            );
        } else {
            this.db.run(
                'INSERT INTO users (id, name, email, goal) VALUES (1, ?, ?, ?)', [user.name || '', user.email || '', user.goal || 'General Fitness']
            );
        }

        this.saveToStorage();
        localStorage.setItem('fitlogic_user', JSON.stringify(user));
    }

    async getUser() {
        if (!this.db) await this.init();

        const result = this.db.exec('SELECT * FROM users WHERE id = 1');
        if (!result || !result[0] || !result[0].values || !result[0].values.length) return null;

        const row = result[0].values[0];
        return {
            id: row[0],
            name: row[1],
            email: row[2],
            goal: row[3]
        };
    }

    async saveSetting(key, value) {
        if (!this.db) await this.init();

        const existingResult = this.db.exec("SELECT id FROM user_settings WHERE \`key\` = ? AND user_id = 1", [key]);
        if (existingResult.length > 0 && existingResult[0].values && existingResult[0].values.length > 0) {
            this.db.run(
                'UPDATE user_settings SET value = ?, updated_at = CURRENT_TIMESTAMP WHERE \`key\` = ? AND user_id = 1', [value, key]
            );
        } else {
            this.db.run(
                'INSERT INTO user_settings (user_id, \`key\`, value) VALUES (1, ?, ?)', [key, value]
            );
        }

        this.saveToStorage();
    }

    async getSetting(key) {
        if (!this.db) await this.init();

        const result = this.db.exec("SELECT value FROM user_settings WHERE \`key\` = ? AND user_id = 1", [key]);
        if (!result || !result[0] || !result[0].values || !result[0].values.length) return null;
        return result[0].values[0][0];
    }

    async saveMealLog(meal) {
        if (!this.db) await this.init();

        this.db.run(`
            INSERT INTO meal_logs (
                user_id, date, meal_type, name, calories, protein, carbs, fats, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            1,
            meal.date || new Date().toISOString().split('T')[0],
            meal.mealType || 'Snack',
            meal.name || '',
            meal.calories || 0,
            meal.protein || 0,
            meal.carbs || 0,
            meal.fats || 0,
            meal.notes || null
        ]);

        this.saveToStorage();
    }

    async saveFeedback(feedback) {
        if (!this.db) await this.init();

        this.db.run(`
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER DEFAULT 1,
                rating INTEGER,
                \`text\` TEXT,
                email TEXT,
                \`user\` TEXT,
                date DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        this.db.run(`
            INSERT INTO feedback (user_id, rating, \`text\`, email, \`user\`, date)
            VALUES (1, ?, ?, ?, ?, ?)
        `, [feedback.rating, feedback.text, feedback.email, feedback.user, feedback.date]);

        this.saveToStorage();
        return true;
    }

    async syncToLocalStorage(type) {}

    // Global instance and auto-init - browser only
    if (typeof window !== 'undefined') {
        window.fitlogicDB = new FitLogicDB();
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                window.fitlogicDB.init().catch(() => {});
            });
        } else {
            window.fitlogicDB.init().catch(() => {});
        }
        window.FitLogicDB = FitLogicDB;
    }

    // Module exports - Node.js
    if (typeof module !== 'undefined' && module.exports) {
        module.exports = FitLogicDB;
    }