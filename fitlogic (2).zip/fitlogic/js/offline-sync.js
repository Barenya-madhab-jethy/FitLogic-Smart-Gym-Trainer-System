// Offline Sync Manager
class OfflineSync {
    constructor() {
        this.db = null;
        this.syncInProgress = false;
        this.init();
    }

    async init() {
        await this.openDB();
        this.registerSync();
        this.setupEventListeners();
    }

    async openDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open('FitLogicDB', 1);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.db = request.result;
                resolve(this.db);
            };

            request.onupgradeneeded = event => {
                const db = event.target.result;

                if (!db.objectStoreNames.contains('offlineWorkouts')) {
                    const workoutStore = db.createObjectStore('offlineWorkouts', { keyPath: 'id', autoIncrement: true });
                    workoutStore.createIndex('timestamp', 'timestamp');
                }

                if (!db.objectStoreNames.contains('offlineNutrition')) {
                    const nutritionStore = db.createObjectStore('offlineNutrition', { keyPath: 'id', autoIncrement: true });
                    nutritionStore.createIndex('timestamp', 'timestamp');
                }

                if (!db.objectStoreNames.contains('userSettings')) {
                    db.createObjectStore('userSettings');
                }
            };
        });
    }

    setupEventListeners() {
        window.addEventListener('online', () => {
            console.log('Back online - starting sync');
            this.sync();
        });

        window.addEventListener('offline', () => {
            console.log('Offline - storing locally');
            this.showOfflineIndicator();
        });
    }

    async saveOfflineWorkout(workout) {
        if (!this.db) await this.openDB();

        const tx = this.db.transaction('offlineWorkouts', 'readwrite');
        const store = tx.objectStore('offlineWorkouts');

        const offlineWorkout = {
            ...workout,
            timestamp: Date.now(),
            synced: false
        };

        return new Promise((resolve, reject) => {
            const request = store.add(offlineWorkout);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async saveOfflineMeal(meal) {
        if (!this.db) await this.openDB();

        const tx = this.db.transaction('offlineNutrition', 'readwrite');
        const store = tx.objectStore('offlineNutrition');

        const offlineMeal = {
            ...meal,
            timestamp: Date.now(),
            synced: false
        };

        return new Promise((resolve, reject) => {
            const request = store.add(offlineMeal);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getOfflineWorkouts() {
        if (!this.db) await this.openDB();

        const tx = this.db.transaction('offlineWorkouts', 'readonly');
        const store = tx.objectStore('offlineWorkouts');

        return new Promise((resolve, reject) => {
            const request = store.getAll();
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getOfflineMeals() {
        if (!this.db) await this.openDB();

        const tx = this.db.transaction('offlineNutrition', 'readonly');
        const store = tx.objectStore('offlineNutrition');

        return new Promise((resolve, reject) => {
            const request = store.getAll();
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async sync() {
        if (this.syncInProgress || !navigator.onLine) return;

        this.syncInProgress = true;
        this.showSyncIndicator();

        try {
            await this.syncWorkouts();
            await this.syncNutrition();
            await this.syncSettings();

            this.hideSyncIndicator();
            this.showSyncComplete();
        } catch (error) {
            console.error('Sync failed:', error);
            this.showSyncError();
        } finally {
            this.syncInProgress = false;
        }
    }

    async syncWorkouts() {
        const workouts = await this.getOfflineWorkouts();

        for (const workout of workouts) {
            try {
                const response = await fetch('/api/sync-workout', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(workout)
                });

                if (response.ok) {
                    const tx = this.db.transaction('offlineWorkouts', 'readwrite');
                    const store = tx.objectStore('offlineWorkouts');
                    await store.delete(workout.id);
                }
            } catch (error) {
                console.error('Workout sync failed:', error);
            }
        }
    }

    async syncNutrition() {
        const meals = await this.getOfflineMeals();

        for (const meal of meals) {
            try {
                const response = await fetch('/api/sync-meal', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(meal)
                });

                if (response.ok) {
                    const tx = this.db.transaction('offlineNutrition', 'readwrite');
                    const store = tx.objectStore('offlineNutrition');
                    await store.delete(meal.id);
                }
            } catch (error) {
                console.error('Meal sync failed:', error);
            }
        }
    }

    async syncSettings() {
        // Sync user settings if needed
    }

    registerSync() {
        if ('serviceWorker' in navigator && 'SyncManager' in window) {
            navigator.serviceWorker.ready.then(registration => {
                // Register periodic sync for workouts
                registration.periodicSync.register('sync-workouts', {
                    minInterval: 24 * 60 * 60 * 1000 // 1 day
                }).catch(error => {
                    console.error('Periodic sync registration failed:', error);
                });
            });
        }
    }

    showOfflineIndicator() {
        let indicator = document.getElementById('offlineIndicator');

        if (!indicator) {
            indicator = document.createElement('div');
            indicator.id = 'offlineIndicator';
            indicator.className = 'offline-indicator';
            indicator.innerHTML = `
                <i class="fas fa-wifi-slash"></i>
                <span>You're offline - changes will sync when online</span>
            `;
            document.body.appendChild(indicator);
        }

        indicator.classList.add('show');
    }

    showSyncIndicator() {
        let indicator = document.getElementById('syncIndicator');

        if (!indicator) {
            indicator = document.createElement('div');
            indicator.id = 'syncIndicator';
            indicator.className = 'sync-indicator';
            indicator.innerHTML = `
                <div class="spinner"></div>
                <span>Syncing...</span>
            `;
            document.body.appendChild(indicator);
        }

        indicator.classList.add('show');
    }

    hideSyncIndicator() {
        const indicator = document.getElementById('syncIndicator');
        if (indicator) {
            indicator.classList.remove('show');
        }
    }

    showSyncComplete() {
        const toast = document.createElement('div');
        toast.className = 'sync-toast';
        toast.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <span>Sync complete!</span>
        `;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.remove();
        }, 3000);
    }

    showSyncError() {
        const toast = document.createElement('div');
        toast.className = 'sync-toast error';
        toast.innerHTML = `
            <i class="fas fa-exclamation-circle"></i>
            <span>Sync failed - will retry later</span>
        `;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.remove();
        }, 3000);
    }

    getPendingCount() {
        return Promise.all([
            this.getOfflineWorkouts(),
            this.getOfflineMeals()
        ]).then(([workouts, meals]) => workouts.length + meals.length);
    }
}

// Initialize offline sync
const offlineSync = new OfflineSync();

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = offlineSync;
}