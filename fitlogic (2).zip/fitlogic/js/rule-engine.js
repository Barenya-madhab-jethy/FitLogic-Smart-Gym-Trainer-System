// Rule-Based Decision Engine
class RuleEngine {
    constructor() {
        this.rules = [];
        this.userData = {};
        this.workoutLogs = [];
        this.initRules();
    }

    initRules() {
        // Rule 1: Muscle Balance Detection
        this.addRule({
            id: 'muscle_balance',
            condition: (data) => {
                const chestCount = this.getMuscleFrequency('chest', 7);
                const legCount = this.getMuscleFrequency('legs', 7);
                return chestCount >= 3 && chestCount > legCount * 2;
            },
            action: (data) => ({
                type: 'warning',
                message: 'Chest trained too frequently! Take 48h rest and focus on back + mobility.',
                suggestions: ['Back exercises', 'Mobility work', 'Rest day'],
                severity: 'high'
            })
        });

        // Rule 2: Overtraining Detection
        this.addRule({
            id: 'overtraining',
            condition: (data) => {
                const perfDrop = this.checkPerformanceDrop(5);
                const sleepAvg = this.getAverageSleep(3);
                return perfDrop && sleepAvg < 6;
            },
            action: (data) => ({
                type: 'alert',
                message: 'Overtraining detected! Consider a deload week.',
                suggestions: ['Deload week', 'Light cardio', 'Focus on recovery'],
                severity: 'critical'
            })
        });

        // Rule 3: Plateau Detection
        this.addRule({
            id: 'plateau',
            condition: (data) => {
                return this.checkPlateau(4);
            },
            action: (data) => ({
                type: 'info',
                message: 'Plateau detected! Try progressive overload.',
                suggestions: ['Increase weight by 5%', 'Change rep range', 'Add drop sets'],
                severity: 'medium'
            })
        });

        // Rule 4: Injury Recovery
        this.addRule({
            id: 'injury_recovery',
            condition: (data) => {
                return data.injury && this.getDaysSinceInjury() < 30;
            },
            action: (data) => {
                const days = this.getDaysSinceInjury();
                let intensity = 40;
                if (days > 14) intensity = 55;
                if (days > 21) intensity = 70;

                return {
                    type: 'recovery',
                    message: 'Injury recovery mode active (' + intensity + '% intensity)',
                    suggestions: ['Follow modified exercises', 'Focus on form', 'Week ' + Math.ceil(days / 7) + ' of recovery'],
                    intensity: intensity
                };
            }
        });

        // Rule 5: Motivation Drop
        this.addRule({
            id: 'motivation_drop',
            condition: (data) => {
                const currentFreq = this.getWorkoutFrequency(7);
                const previousFreq = this.getWorkoutFrequency(14, 7);
                return currentFreq < previousFreq * 0.6;
            },
            action: (data) => ({
                type: 'motivation',
                message: 'Do not lose momentum! Check your progress and stay consistent!',
                suggestions: ['View progress recap', 'Set new goal', 'Try a new routine'],
                severity: 'medium'
            })
        });

        // Rule 6: Sleep-Based Intensity
        this.addRule({
            id: 'sleep_adjustment',
            condition: (data) => {
                return data.sleep !== undefined;
            },
            action: (data) => {
                let intensity = 100;
                let rest = 60;

                if (data.sleep < 5) {
                    intensity = 70;
                    rest = 90;
                } else if (data.sleep < 7) {
                    intensity = 85;
                    rest = 75;
                }

                return {
                    type: 'adjustment',
                    message: 'Sleep: ' + data.sleep + 'h - Intensity adjusted to ' + intensity + '%',
                    intensity: intensity,
                    rest: rest,
                    suggestions: ['Longer rest periods', 'Focus on form']
                };
            }
        });

        // Rule 7: Time-Based Workout Selection
        this.addRule({
            id: 'time_based',
            condition: (data) => {
                return data.timeAvailable !== undefined;
            },
            action: (data) => {
                const time = data.timeAvailable;
                const workoutType = time <= 15 ? 'Express' : time <= 30 ? 'Standard' : time <= 45 ? 'Extended' : 'Complete';
                const exercises = time <= 15 ? ['Compound lifts only', 'Supersets'] : time <= 30 ? ['Compound + accessory', 'Moderate volume'] : time <= 45 ? ['Full routine', 'Include isolation'] : ['Warmup + compound + isolation + cardio'];

                return {
                    type: 'workout',
                    message: time + 'min workout: ' + workoutType + ' mode',
                    exercises: exercises,
                    duration: time
                };
            }
        });

        // Rule 8: Fitness Score Calculation
        this.addRule({
            id: 'fitness_score',
            condition: (data) => true,
            action: (data) => {
                const score = this.calculateFitnessScore();
                return {
                    type: 'score',
                    message: 'Your Fitness Score: ' + score + '/100',
                    components: {
                        consistency: this.calculateConsistency(),
                        strength: this.calculateStrengthGrowth(),
                        recovery: this.calculateRecovery(),
                        balance: this.calculateMuscleBalance()
                    }
                };
            }
        });
    }

    addRule(rule) {
        this.rules.push(rule);
    }

    evaluate(userData, workoutLogs) {
        this.userData = userData;
        this.workoutLogs = workoutLogs;

        const decisions = [];

        for (const rule of this.rules) {
            try {
                if (rule.condition(this.userData)) {
                    const result = rule.action(this.userData);
                    decisions.push(result);
                }
            } catch (error) {
                showToast('Rule ' + rule.id + ' failed', 'error');
            }
        }

        return this.prioritizeDecisions(decisions);
    }

    getMuscleFrequency(muscle, days) {
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - days);

        return this.workoutLogs.filter(log =>
            log.date >= cutoff &&
            log.mainExercises && log.mainExercises.some(ex => ex.muscleGroup === muscle)
        ).length;
    }

    checkPerformanceDrop(sessions) {
        const recent = this.workoutLogs.slice(-sessions);
        if (recent.length < sessions) return false;

        for (let i = 1; i < recent.length; i++) {
            if (recent[i].totalWeight >= recent[i - 1].totalWeight) {
                return false;
            }
        }
        return true;
    }

    getAverageSleep(days) {
        const recent = this.workoutLogs.slice(-days);
        if (recent.length === 0) return 7;

        const sum = recent.reduce((acc, log) => acc + (log.sleep || 7), 0);
        return sum / recent.length;
    }

    checkPlateau(sessions) {
        const recent = this.workoutLogs.slice(-sessions);
        if (recent.length < sessions) return false;

        const weight = recent[0].weight;
        return recent.every(log => log.weight === weight);
    }

    getDaysSinceInjury() {
        if (!this.userData.injuryDate) return 999;
        const injuryDate = new Date(this.userData.injuryDate);
        const today = new Date();
        const diffTime = Math.abs(today - injuryDate);
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }

    getWorkoutFrequency(days, offset) {
        offset = offset || 0;
        const start = new Date();
        start.setDate(start.getDate() - days - offset);
        const end = new Date();
        end.setDate(end.getDate() - offset);

        return this.workoutLogs.filter(log =>
            log.date >= start && log.date <= end
        ).length;
    }

    getTrend() {
        const recent = this.workoutLogs.slice(-10);
        if (recent.length < 5) return 'stable';

        let improving = 0;
        let declining = 0;

        for (let i = 1; i < recent.length; i++) {
            if (recent[i].score > recent[i - 1].score) improving++;
            if (recent[i].score < recent[i - 1].score) declining++;
        }

        if (improving > declining * 2) return 'improving';
        if (declining > improving * 2) return 'declining';
        return 'stable';
    }

    calculateFitnessScore() {
        const consistency = this.calculateConsistency() * 0.3;
        const strength = this.calculateStrengthGrowth() * 0.25;
        const recovery = this.calculateRecovery() * 0.2;
        const balance = this.calculateMuscleBalance() * 0.25;

        return Math.round(consistency + strength + recovery + balance);
    }

    calculateConsistency() {
        const total = this.workoutLogs.length;
        const expected = 30; // Expected workouts in 30 days
        return Math.min(100, (total / expected) * 100);
    }

    calculateStrengthGrowth() {
        if (this.workoutLogs.length < 2) return 50;

        const first = this.workoutLogs[0].totalWeight;
        const last = this.workoutLogs[this.workoutLogs.length - 1].totalWeight;

        if (first === 0) return 50;

        const growth = ((last - first) / first) * 100;
        return Math.min(100, Math.max(0, 50 + growth));
    }

    calculateRecovery() {
        const sleepAvg = this.getAverageSleep(7);
        return Math.min(100, (sleepAvg / 8) * 100);
    }

    calculateMuscleBalance() {
        const muscleGroups = ['chest', 'back', 'legs', 'shoulders', 'arms', 'core'];
        const counts = {};

        muscleGroups.forEach(function(m) { counts[m] = 0; });

        this.workoutLogs.forEach(function(log) {
            if (log.mainExercises) {
                log.mainExercises.forEach(function(ex) {
                    if (counts[ex.muscleGroup] !== undefined) {
                        counts[ex.muscleGroup]++;
                    }
                });
            }
        });

        const max = Math.max.apply(null, Object.values(counts));
        const min = Math.min.apply(null, Object.values(counts));

        if (max === 0) return 50;

        const balance = (min / max) * 100;
        return balance;
    }

    prioritizeDecisions(decisions) {
        const priority = {
            'critical': 4,
            'high': 3,
            'medium': 2,
            'low': 1
        };

        return decisions.sort(function(a, b) {
            return (priority[b.severity] || 0) - (priority[a.severity] || 0);
        });
    }
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = RuleEngine;
}

// Expose to global scope for browser
if (typeof window !== 'undefined') {
    window.RuleEngine = RuleEngine;
}