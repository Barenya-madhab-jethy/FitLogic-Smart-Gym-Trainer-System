// Main JavaScript for FitLogic
// Initialize all components and handle global functionality

// Global variables
let currentUser = null;
let fitnessScore;
let charts;
let ruleEngine;
let workoutGenerator;


// Load user data from localStorage
function loadUserData() {
    const savedUser = localStorage.getItem('fitlogic_user');
    if (savedUser) {
        try {
            currentUser = JSON.parse(savedUser);
            updateUIForUser();
        } catch (e) {
            console.warn('Invalid user data, clearing:', e);
            localStorage.removeItem('fitlogic_user');
        }
    }

    // Load workouts
    const workouts = JSON.parse(localStorage.getItem('fitlogic_workouts') || '[]');

    // Load preferences
    const preferences = JSON.parse(localStorage.getItem('fitlogic_preferences') || '{}');
}

function initializeComponents() {
    // Initialize fitness score
    fitnessScore = new FitnessScore();

    // Initialize charts
    charts = new FitLogicCharts();

    // Initialize rule engine
    ruleEngine = new RuleEngine();

    // Initialize workout generator
    workoutGenerator = new WorkoutGenerator();

    // Skip dashboard chart initialization - dashboard.html handles it separately
    // This prevents duplicate chart creation

    // Initialize tooltips
    initTooltips();

    // Initialize dropdowns
    initDropdowns();

    // Initialize sliders
    initSliders();

    // Check for offline indicator
    if (!navigator.onLine) {
        showOfflineIndicator();
    }
}

// Initialize Bootstrap tooltips
function initTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Initialize Bootstrap dropdowns
function initDropdowns() {
    const dropdownElementList = [].slice.call(document.querySelectorAll('.dropdown-toggle'));
    dropdownElementList.map(function(dropdownToggleEl) {
        return new bootstrap.Dropdown(dropdownToggleEl);
    });
}

// Initialize range sliders
function initSliders() {
    document.querySelectorAll('input[type="range"]').forEach(slider => {
        slider.addEventListener('input', (e) => {
            const valueDisplay = document.getElementById(slider.id + 'Value');
            if (valueDisplay) {
                if (slider.id.includes('sleep')) {
                    valueDisplay.textContent = e.target.value + ' hrs';
                } else if (slider.id.includes('stress')) {
                    valueDisplay.textContent = e.target.value + '/10';
                } else {
                    valueDisplay.textContent = e.target.value;
                }
            }
        });
    });
}

// Setup global event listeners
function setupEventListeners() {
    // Online/Offline events
    window.addEventListener('online', () => {
        hideOfflineIndicator();
        syncData();
    });

    window.addEventListener('offline', showOfflineIndicator);

    // Before unload save data
    window.addEventListener('beforeunload', () => {
        saveUserData();
    });

    // Handle auth modal
    const authLinks = document.querySelectorAll('[href="#auth"]');
    authLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            showAuthModal();
        });
    });
}

// Check for active injury mode
function checkInjuryMode() {
    const injury = JSON.parse(localStorage.getItem('fitlogic_injury') || 'null');
    if (injury) {
        // Show injury mode banner
        showInjuryBanner(injury);

        // Modify workouts if on workout page
        if (window.location.pathname.includes('workout')) {
            const injuryBanner = document.getElementById('injuryModeActive');
            if (injuryBanner) {
                injuryBanner.style.display = 'block';
            }
        }
    }
}

// Show injury mode banner
function showInjuryBanner(injury) {
    const banner = document.createElement('div');
    banner.className = 'injury-banner';
    banner.innerHTML = `
        <div class="container">
            <i class="fas fa-bone"></i>
            <span>Recovery Mode Active: ${injury.type} injury - Training at reduced intensity</span>
            <button onclick="window.location.href='injury-mode.html'">View Details</button>
        </div>
    `;
    document.body.insertBefore(banner, document.body.firstChild);
}

// Register service worker for offline support
function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('sw.js')
            .then(registration => {
                // ServiceWorker registered successfully

                // Check for updates
                registration.addEventListener('updatefound', () => {
                    const newWorker = registration.installing;
                    // New service worker installing
                });
            })
            .catch(error => {
                console.error('ServiceWorker registration failed:', error);
            });

        // Listen for messages from service worker
        navigator.serviceWorker.addEventListener('message', event => {
            if (event.data.type === 'CACHE_UPDATED') {
                showToast('App updated - refresh for new features');
            }
        });
    }
}

// Check online status
function checkOnlineStatus() {
    if (!navigator.onLine) {
        showOfflineIndicator();
    }
}

// Show offline indicator
function showOfflineIndicator() {
    let indicator = document.getElementById('offlineIndicator');
    if (!indicator) {
        indicator = document.createElement('div');
        indicator.id = 'offlineIndicator';
        indicator.className = 'offline-indicator';
        indicator.innerHTML = `
            <i class="fas fa-wifi-slash"></i>
            <span>You're offline - changes will sync when online</span>
        `;
        document.body.appendChild(indicator);
    }
    indicator.classList.add('show');
}

// Hide offline indicator
function hideOfflineIndicator() {
    const indicator = document.getElementById('offlineIndicator');
    if (indicator) {
        indicator.classList.remove('show');
    }
}

// Sync data when back online
function syncData() {
    showToast('Syncing data...', 'info');

    // Sync workouts
    const offlineWorkouts = JSON.parse(localStorage.getItem('offline_workouts') || '[]');
    if (offlineWorkouts.length > 0) {
        fetch('/api/sync-workouts', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(offlineWorkouts)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    localStorage.removeItem('offline_workouts');
                    showToast('Workouts synced successfully!');
                }
            })
            .catch(error => {
                console.error('Sync failed:', error);
                showToast('Sync failed - will retry later', 'error');
            });
    }

    // Sync nutrition
    const offlineMeals = JSON.parse(localStorage.getItem('offline_meals') || '[]');
    if (offlineMeals.length > 0) {
        fetch('/api/sync-meals', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(offlineMeals)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    localStorage.removeItem('offline_meals');
                }
            })
            .catch(console.error);
    }
}

// Show authentication modal
function showAuthModal() {
    const modalElement = document.getElementById('authModal');
    if (modalElement) {
        const modal = new bootstrap.Modal(modalElement);
        modal.show();
    }
}

// Toggle between login and signup
function showLogin() {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const tabs = document.querySelectorAll('.auth-tab');

    if (loginForm) loginForm.classList.add('active');
    if (signupForm) signupForm.classList.remove('active');
    if (tabs[0]) tabs[0].classList.add('active');
    if (tabs[1]) tabs[1].classList.remove('active');
}

function showSignup() {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const tabs = document.querySelectorAll('.auth-tab');

    if (loginForm) loginForm.classList.remove('active');
    if (signupForm) signupForm.classList.add('active');
    if (tabs[0]) tabs[0].classList.remove('active');
    if (tabs[1]) tabs[1].classList.add('active');
}

// Save user data
function saveUserData() {
    if (currentUser) {
        localStorage.setItem('fitlogic_user', JSON.stringify(currentUser));
    }
}

// Update UI for logged in user
function updateUIForUser() {
    if (currentUser) {
        const userNameEl = document.getElementById('userName');
        const userEmailEl = document.getElementById('userEmail');
        const userGoalEl = document.getElementById('userGoal');

        // Show toast notification
        if (userGoalEl) userGoalEl.textContent = currentUser.goal || 'Fitness';
    }
}

function showToast(message, type) {
    type = type || 'success';
    const toast = document.createElement('div');
    toast.className = 'sync-toast ' + type;
    let icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'info') icon = 'info-circle';

    toast.innerHTML = '<i class="fas fa-' + icon + '"></i><span>' + message + '</span>';
    document.body.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Calculate weekly strength
function calculateWeeklyStrength(workouts) {
    const weeklyData = [];
    for (let i = 0; i < 6; i++) {
        const weekWorkouts = workouts.filter(w => {
            const date = new Date(w.date);
            const weekAgo = new Date();
            weekAgo.setDate(weekAgo.getDate() - (i * 7));
            const weekStart = new Date(weekAgo);
            weekStart.setDate(weekStart.getDate() - 7);
            return date >= weekStart && date < weekAgo;
        });

        const avgStrength = weekWorkouts.reduce((sum, w) => {
            const exercises = w.mainExercises || [];
            return sum + exercises.reduce((s, ex) => s + (ex.sets * 10), 0);
        }, 0) / (weekWorkouts.length || 1);

        weeklyData.unshift(Math.min(100, avgStrength));
    }
    return weeklyData;
}

// Calculate muscle balance
function calculateMuscleBalance(workouts) {
    const muscles = ['Chest', 'Back', 'Legs', 'Shoulders', 'Arms', 'Core'];
    const counts = {};

    muscles.forEach(function(m) { counts[m] = 0; });

    workouts.slice(-30).forEach(function(workout) {
        const exercises = workout.mainExercises || [];
        exercises.forEach(function(ex) {
            if (counts[ex.muscleGroup]) {
                counts[ex.muscleGroup]++;
            }
        });
    });

    const max = Math.max.apply(null, Object.values(counts));
    return muscles.map(function(m) { return Math.round((counts[m] / (max || 1)) * 100); });
}

// Calculate daily volume
function calculateDailyVolume(workouts) {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const volumes = [0, 0, 0, 0, 0, 0, 0];

    workouts.slice(-7).forEach(function(workout) {
        const day = new Date(workout.date).getDay(); // 0 = Sunday
        const dayIndex = day === 0 ? 6 : day - 1; // Convert to Mon-Sun
        const exercises = workout.mainExercises || [];
        volumes[dayIndex] += exercises.reduce((sum, ex) => sum + (ex.sets * 50), 0);
    });

    return volumes;
}

// Generate Workout function for demo
function generateWorkout() {
    const sleepEl = document.getElementById('sleepDemo');
    const stressEl = document.getElementById('stressDemo');
    const timeEl = document.getElementById('timeDemo');

    const sleep = sleepEl ? parseInt(sleepEl.value) : 7;
    const stress = stressEl ? parseInt(stressEl.value) : 5;
    const timeValue = timeEl ? timeEl.value : '30 min';
    const timeAvailable = parseInt(timeValue.replace(/\D/g, '')) || 30;

    if (workoutGenerator) {
        const workout = workoutGenerator.generateWorkout({
            sleep: sleep,
            stress: stress,
            timeAvailable: timeAvailable,
            equipment: ['dumbbell', 'barbell', 'bodyweight'],
            preferences: [],
            lastWorkouts: JSON.parse(localStorage.getItem('fitlogic_workouts') || '[]')
        });

        // Display workout in demo result
        const demoResult = document.getElementById('demoResult');
        if (demoResult) {
            let workoutHTML = '<h5>Smart Decision:</h5>';
            workoutHTML += '<p>Based on ' + sleep + ' hrs sleep and ' + stress + '/10 stress, we recommend:</p>';
            workoutHTML += '<ul>';
            workoutHTML += '<li>✓ ' + workout.intensity + ' intensity workout</li>';

            const focusExercises = workout.mainExercises.slice(0, 3).map(function(e) { return e.name; });
            workoutHTML += '<li>✓ Focus on: ' + focusExercises.join(', ') + '</li>';
            workoutHTML += '<li>✓ ' + workout.restTimes.compound + 'sec rest periods</li>';
            workoutHTML += '</ul>';
            workoutHTML += '<div class="workout-details mt-3">';
            workoutHTML += '<h6>Full Workout:</h6>';
            workoutHTML += '<ul class="small">';

            workout.warmup.forEach(function(w) {
                workoutHTML += '<li>' + w.name + '</li>';
            });

            workout.mainExercises.slice(0, 4).forEach(function(e) {
                workoutHTML += '<li>' + e.name + ' - ' + e.sets + ' sets x ' + e.reps + '</li>';
            });

            workoutHTML += '</ul></div>';

            demoResult.innerHTML = workoutHTML;
        }
    } else {
        // Fallback if workout generator not initialized
        const demoResult = document.getElementById('demoResult');
        if (demoResult) {
            demoResult.innerHTML = '<h5>Smart Decision:</h5>' +
                '<p>Based on ' + sleep + ' hrs sleep and ' + stress + '/10 stress, we recommend:</p>' +
                '<ul>' +
                '<li>✓ Moderate intensity workout</li>' +
                '<li>✓ Focus on compound movements</li>' +
                '<li>✓ 60 sec rest periods</li>' +
                '</ul>' +
                '<button class="btn btn-neon mt-2" onclick="window.location.href=\'dashboard.html\'">Go to Dashboard</button>';
        }
    }
}

// Demo tab functionality
function setupDemoTabs() {
    const demoTabs = document.querySelectorAll('.demo-tab');
    demoTabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            demoTabs.forEach(function(t) { t.classList.remove('active'); });
            // Add active class to clicked tab
            this.classList.add('active');

            // Here you could add logic to show different demo content
            const demoType = this.getAttribute('data-demo');
            console.log('Demo tab switched to:', demoType);
        });
    });
}

// Authentication handlers
function handleLogin(e) {
    e.preventDefault();

    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;

    if (!email || !password || !email.includes('@')) {
        showToast('Please enter valid email and password', 'error');
        return;
    }

    // Mock successful login - create user object
    const user = {
        name: email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1),
        email: email,
        goal: 'General Fitness',
        loginTime: new Date().toISOString()
    };

    localStorage.setItem('fitlogic_user', JSON.stringify(user));
    currentUser = user;
    updateUIForUser();

    showToast('Login successful! Welcome back.', 'success');

    // Redirect to dashboard
    setTimeout(() => {
        window.location.href = 'dashboard.html';
    }, 800);
}

function handleSignup(e) {
    e.preventDefault();

    const name = document.getElementById('signupName').value.trim();
    const email = document.getElementById('signupEmail').value.trim();
    const password = document.getElementById('signupPassword').value;
    const goal = document.getElementById('signupGoal').value;

    if (!name || !email || !password || !email.includes('@')) {
        showToast('Please fill all fields with valid data', 'error');
        return;
    }

    // Mock successful signup
    const user = {
        name: name,
        email: email,
        goal: goal,
        loginTime: new Date().toISOString()
    };

    localStorage.setItem('fitlogic_user', JSON.stringify(user));
    currentUser = user;

    showToast('Account created successfully! Logging in...', 'success');

    // Redirect to dashboard
    setTimeout(() => {
        window.location.href = 'dashboard.html';
    }, 800);
}

// Export functions for use in HTML
window.showLogin = showLogin;
window.showSignup = showSignup;
window.showAuthModal = showAuthModal;
window.handleLogin = handleLogin;
window.handleSignup = handleSignup; // Chat functions defined in js/chatbot.js