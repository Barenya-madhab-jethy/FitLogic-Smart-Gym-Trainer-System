// DeepSeek API Chatbot Integration
class Chatbot {
    constructor() {
        this.apiKey = 'sk-9877f03ff3b34ffb8efbb63f12129c51';
        this.apiUrl = 'https://api.deepseek.com/v1/chat/completions';
        this.messages = [];
        this.isTyping = false;
        this.init();
    }

    init() {
        this.loadMessages();
        this.setupEventListeners();
    }

    setupEventListeners() {
        const chatInput = document.getElementById('chatInput');
        if (chatInput) {
            chatInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.sendMessage();
                }
            });
        }

        const sendBtn = document.querySelector('.chatbot-input button');
        if (sendBtn) {
            sendBtn.addEventListener('click', () => {
                this.sendMessage();
            });
        }
    }

    async sendMessage() {
        const chatInput = document.getElementById('chatInput');
        if (!chatInput) return;

        let message = chatInput.value;
        if (!message.trim()) return;

        this.addMessage(message, 'user');
        chatInput.value = '';
        this.showTypingIndicator();

        try {
            const response = await this.callDeepSeekAPI(message);
            this.hideTypingIndicator();
            this.addMessage(response, 'bot');
        } catch (error) {
            console.error('Chatbot error:', error);
            this.hideTypingIndicator();
            const fallbackResponse = this.getFallbackResponse(message);
            this.addMessage(fallbackResponse, 'bot');
        }
    }

    async callDeepSeekAPI(message) {
        const context = this.getContextPrompt();

        const response = await fetch(this.apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + this.apiKey
            },
            body: JSON.stringify({
                model: 'deepseek-chat',
                messages: [{
                        role: 'system',
                        content: 'You are FitLogic AI, a fitness assistant. Help with workouts, nutrition, recovery. Keep responses concise and practical. Context: ' + context
                    },
                    ...this.messages.slice(-5).map(function(m) {
                        return {
                            role: m.sender === 'user' ? 'user' : 'assistant',
                            content: m.text
                        };
                    }),
                    {
                        role: 'user',
                        content: message
                    }
                ],
                temperature: 0.7,
                max_tokens: 500
            })
        });

        const data = await response.json();

        if (data.choices && data.choices[0]) {
            return data.choices[0].message.content;
        } else if (data.error) {
            throw new Error(data.error.message || 'API Error');
        } else {
            throw new Error('Invalid API response');
        }
    }

    getContextPrompt() {
        let userData = {};
        try {
            userData = JSON.parse(localStorage.getItem('fitlogic_user') || '{}');
        } catch (e) {
            console.error('Error parsing user data:', e);
        }

        let recentWorkouts = [];
        try {
            recentWorkouts = JSON.parse(localStorage.getItem('fitlogic_workouts') || '[]');
        } catch (e) {
            console.error('Error parsing workouts:', e);
        }

        return 'User: ' + (userData.name || 'Guest') + ' | Goal: ' + (userData.goal || 'Not set') + ' | Workouts: ' + recentWorkouts.length + ' | Score: ' + (localStorage.getItem('fitlogic_score') || '0');
    }

    getFallbackResponse(message) {
        let lowerMessage = message.toLowerCase();

        if (lowerMessage.indexOf('workout') !== -1 || lowerMessage.indexOf('train') !== -1 || lowerMessage.indexOf('exercise') !== -1) {
            return 'Based on your preferences, I recommend a balanced workout targeting major muscle groups. Start with a 5-10 minute warmup, then focus on compound exercises like squats, push-ups, and rows. Finish with stretching.';
        }
        if (lowerMessage.indexOf('nutrition') !== -1 || lowerMessage.indexOf('food') !== -1 || lowerMessage.indexOf('eat') !== -1 || lowerMessage.indexOf('diet') !== -1 || lowerMessage.indexOf('meal') !== -1) {
            return 'For optimal fitness, focus on: 1) Adequate protein (1.6-2g per kg body weight), 2) Complex carbs for energy, 3) Healthy fats for hormone production, and 4) Stay hydrated!';
        }
        if (lowerMessage.indexOf('sleep') !== -1 || lowerMessage.indexOf('rest') !== -1 || lowerMessage.indexOf('recovery') !== -1) {
            return 'Quality sleep is crucial for recovery. Aim for 7-9 hours per night. Tips: Keep a consistent sleep schedule, Avoid screens before bed, Keep your room cool, Avoid caffeine after 2pm.';
        }
        if (lowerMessage.indexOf('weight') !== -1 || lowerMessage.indexOf('loss') !== -1 || lowerMessage.indexOf('fat') !== -1 || lowerMessage.indexOf('slim') !== -1) {
            return 'For weight loss: Create a calorie deficit of 300-500 kcal/day through diet and exercise. Focus on protein intake to preserve muscle, and combine strength training with cardio.';
        }
        if (lowerMessage.indexOf('muscle') !== -1 || lowerMessage.indexOf('build') !== -1 || lowerMessage.indexOf('gain') !== -1 || lowerMessage.indexOf('strength') !== -1) {
            return 'To build muscle: 1) Progressive overload (gradually increase weight/reps), 2) Eat enough protein, 3) Get adequate sleep, 4) Train each muscle group 2-3 times per week.';
        }
        if (lowerMessage.indexOf('cardio') !== -1 || lowerMessage.indexOf('running') !== -1 || lowerMessage.indexOf('cycling') !== -1 || lowerMessage.indexOf('hiit') !== -1) {
            return 'Cardio recommendations: 150 minutes moderate or 75 minutes vigorous per week. Include both steady-state and HIIT. Start gradually if you are new.';
        }
        if (lowerMessage.indexOf('injury') !== -1 || lowerMessage.indexOf('pain') !== -1 || lowerMessage.indexOf('hurt') !== -1 || lowerMessage.indexOf('injured') !== -1) {
            return 'If you have an injury: 1) Rest and proper recovery, 2) Consult a professional, 3) Focus on mobility work, 4) Return gradually when pain-free.';
        }
        if (lowerMessage.indexOf('beginner') !== -1 || lowerMessage.indexOf('start') !== -1 || lowerMessage.indexOf('new') !== -1) {
            return 'Welcome! Start with: 2-3 workouts per week, Full body routines, Learn proper form, Focus on consistency over intensity.';
        }
        if (lowerMessage.indexOf('indian') !== -1 || lowerMessage.indexOf('dal') !== -1 || lowerMessage.indexOf('roti') !== -1 || lowerMessage.indexOf('rice') !== -1) {
            return 'Indian diet tips: Include dal, legumes for protein, Whole grains like brown rice/ragi, Fresh vegetables and fruits, Limit processed foods and sugar.';
        }

        return "I'm here to help with your fitness journey! Ask me about workouts, nutrition, sleep, recovery, or any fitness-related questions.";
    }

    addMessage(text, sender) {
        let messagesContainer = document.getElementById('chatMessages');
        if (!messagesContainer) return;

        let messageDiv = document.createElement('div');
        messageDiv.className = 'message ' + sender;

        let contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        contentDiv.textContent = text;

        messageDiv.appendChild(contentDiv);
        messagesContainer.appendChild(messageDiv);

        this.messages.push({
            text: text,
            sender: sender,
            timestamp: new Date().toISOString()
        });

        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        this.saveMessages();
    }

    showTypingIndicator() {
        if (this.isTyping) return;

        let messagesContainer = document.getElementById('chatMessages');
        if (!messagesContainer) return;

        let indicatorDiv = document.createElement('div');
        indicatorDiv.className = 'message bot typing-indicator';
        indicatorDiv.id = 'typingIndicator';

        let dotsDiv = document.createElement('div');
        dotsDiv.className = 'typing-dots';
        dotsDiv.innerHTML = '<span></span><span></span><span></span>';

        indicatorDiv.appendChild(dotsDiv);
        messagesContainer.appendChild(indicatorDiv);

        this.isTyping = true;
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    hideTypingIndicator() {
        let indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.remove();
        }
        this.isTyping = false;
    }

    saveMessages() {
        if (this.messages.length > 50) {
            this.messages = this.messages.slice(-50);
        }
        try {
            localStorage.setItem('fitlogic_chat_history', JSON.stringify(this.messages));
        } catch (e) {
            console.error('Error saving chat history:', e);
        }
    }

    loadMessages() {
        try {
            let saved = localStorage.getItem('fitlogic_chat_history');
            if (saved) {
                this.messages = JSON.parse(saved);
                let messagesContainer = document.getElementById('chatMessages');
                if (messagesContainer) {
                    messagesContainer.innerHTML = '';
                    let self = this;
                    this.messages.forEach(function(msg) {
                        self.addMessage(msg.text, msg.sender);
                    });
                }
            }
        } catch (e) {
            console.error('Error loading chat history:', e);
            this.messages = [];
        }
    }

    clearHistory() {
        this.messages = [];
        localStorage.removeItem('fitlogic_chat_history');

        let messagesContainer = document.getElementById('chatMessages');
        if (messagesContainer) {
            messagesContainer.innerHTML = '';
            this.addMessage('Hi! I am your FitLogic assistant. Ask me anything about workouts, nutrition, or fitness!', 'bot');
        }
    }

    getSuggestedResponses() {
        return [
            'How should I train today?',
            'What should I eat before workout?',
            'I feel tired, should I rest?',
            'How to break a plateau?',
            'Best exercises for chest?',
            'Indian diet for weight loss?'
        ];
    }
}

// Initialize chatbot
let chatbot;

function initChatbot() {
    if (!chatbot) {
        chatbot = new Chatbot();
    }
    return chatbot;
}

// Global functions for HTML onclick
function toggleChatbot() {
    let win = document.getElementById('chatbotWindow');
    if (win) {
        win.classList.toggle('active');
    }
}

function sendMessage() {
    if (chatbot) {
        chatbot.sendMessage();
    } else {
        chatbot = initChatbot();
        chatbot.sendMessage();
    }
}

function handleChatKeypress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

// Initialize on DOMContentLoaded
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        initChatbot();
    }, 100);
});

// Export to window for global access
window.toggleChatbot = toggleChatbot;
window.sendMessage = sendMessage;
window.handleChatKeypress = handleChatKeypress;