/* DEPRECATED - Use js/sql-db-fixed.js instead
This file is no longer used */