// Charts and Visualizations for FitLogic
class FitLogicCharts {
    constructor() {
        this.charts = {};
    }

    // Create Fitness Score Gauge Chart
    createScoreGauge(containerId, score) {
        const canvas = document.getElementById(containerId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        // Clear previous chart
        if (this.charts[containerId]) {
            this.charts[containerId].destroy();
        }

        this.charts[containerId] = new Chart(ctx, {
            type: 'doughnut',
            data: {
                datasets: [{
                    data: [score, 100 - score],
                    backgroundColor: ['#00ff88', 'rgba(255, 255, 255, 0.1)'],
                    borderWidth: 0,
                    circumference: 180,
                    rotation: 270
                }]
            },
            options: {
                cutout: '70%',
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false },
                    tooltip: { enabled: false }
                }
            }
        });

        // Add center text
        const centerText = document.createElement('div');
        centerText.className = 'gauge-center';
        centerText.innerHTML = `
            <span class="gauge-value">${score}</span>
            <span class="gauge-label">Fitness Score</span>
        `;

        const container = canvas.parentElement;
        container.style.position = 'relative';
        container.appendChild(centerText);
    }

    // Create Strength Progress Line Chart
    createStrengthChart(containerId, data) {
        const canvas = document.getElementById(containerId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts[containerId]) {
            this.charts[containerId].destroy();
        }

        this.charts[containerId] = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels || ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'],
                datasets: [{
                    label: 'Strength Score',
                    data: data.values || [65, 70, 68, 75, 82, 88],
                    borderColor: '#00ff88',
                    backgroundColor: 'rgba(0, 255, 136, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: '#00ff88',
                    pointBorderColor: '#fff',
                    pointRadius: 5,
                    pointHoverRadius: 7
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#00ff88',
                        bodyColor: '#fff',
                        borderColor: '#00ff88',
                        borderWidth: 1
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: {
                            color: '#b0b0b0',
                            callback: value => value + '%'
                        }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#b0b0b0' }
                    }
                }
            }
        });
    }

    // Create Muscle Balance Radar Chart
    createMuscleRadarChart(containerId, data) {
        const canvas = document.getElementById(containerId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts[containerId]) {
            this.charts[containerId].destroy();
        }

        this.charts[containerId] = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: data.labels || ['Chest', 'Back', 'Legs', 'Shoulders', 'Arms', 'Core'],
                datasets: [{
                        label: 'Current Balance',
                        data: data.values || [85, 70, 90, 65, 80, 75],
                        backgroundColor: 'rgba(0, 255, 136, 0.2)',
                        borderColor: '#00ff88',
                        pointBackgroundColor: '#00ff88',
                        pointBorderColor: '#fff',
                        pointRadius: 5
                    },
                    {
                        label: 'Target Balance',
                        data: data.target || [80, 80, 80, 80, 80, 80],
                        backgroundColor: 'rgba(255, 255, 255, 0.05)',

                        pointBackgroundColor: 'rgba(255, 255, 255, 0.5)',
                        pointRadius: 3,
                        borderDash: [5, 5]
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100,
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        pointLabels: { color: '#b0b0b0' },
                        ticks: {
                            color: '#b0b0b0',
                            stepSize: 20
                        }
                    }
                }
            }
        });
    }

    // Create Workout Volume Bar Chart
    createVolumeChart(containerId, data) {
        const canvas = document.getElementById(containerId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts[containerId]) {
            this.charts[containerId].destroy();
        }

        this.charts[containerId] = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.labels || ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Volume (kg)',
                    data: data.values || [1200, 1500, 0, 1800, 1300, 2000, 0],
                    backgroundColor: function(context) {
                        const value = context.dataset.data[context.dataIndex];
                        return value === 0 ? 'rgba(255, 68, 68, 0.3)' : '#00ff88';
                    },
                    borderRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#b0b0b0' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#b0b0b0' }
                    }
                }
            }
        });
    }

    // Create Calories Trend Chart
    createCaloriesChart(containerId, data) {
        const canvas = document.getElementById(containerId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts[containerId]) {
            this.charts[containerId].destroy();
        }

        this.charts[containerId] = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels || ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                        label: 'Calories Consumed',
                        data: data.consumed || [2100, 1950, 2200, 2050, 2300, 2400, 2100],
                        borderColor: '#00ff88',
                        backgroundColor: 'rgba(0, 255, 136, 0.1)',
                        yAxisID: 'y',
                        tension: 0.4
                    },
                    {
                        label: 'Calories Burned',
                        data: data.burned || [500, 600, 0, 700, 550, 800, 0],
                        borderColor: '#ff4444',
                        backgroundColor: 'rgba(255, 68, 68, 0.1)',
                        yAxisID: 'y1',
                        tension: 0.4,
                        borderDash: [5, 5]
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: { color: '#b0b0b0' }
                    }
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#00ff88' },
                        title: {
                            display: true,
                            text: 'Calories In',
                            color: '#00ff88'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        grid: { drawOnChartArea: false },
                        ticks: { color: '#ff4444' },
                        title: {
                            display: true,
                            text: 'Calories Out',
                            color: '#ff4444'
                        }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#b0b0b0' }
                    }
                }
            }
        });
    }

    // Create Macro Distribution Pie Chart
    createMacroChart(containerId, data) {
        const canvas = document.getElementById(containerId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts[containerId]) {
            this.charts[containerId].destroy();
        }

        this.charts[containerId] = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Protein', 'Carbs', 'Fats'],
                datasets: [{
                    data: data || [30, 50, 20],
                    backgroundColor: ['#00ff88', '#4169e1', '#8a2be2'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '60%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { color: '#b0b0b0' }
                    }
                }
            }
        });
    }

    // Create Progress Timeline Chart
    createTimelineChart(containerId, data) {
        const canvas = document.getElementById(containerId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts[containerId]) {
            this.charts[containerId].destroy();
        }

        const exercises = data.exercises || ['Bench Press', 'Squat', 'Deadlift'];

        this.charts[containerId] = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.dates || ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
                datasets: exercises.map((exercise, index) => ({
                    label: exercise,
                    data: data[`exercise${index}`] || [60, 65, 70, 75],
                    borderColor: this.getColor(index),
                    backgroundColor: 'transparent',
                    tension: 0.4,
                    pointRadius: 4
                }))
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: { color: '#b0b0b0' }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#b0b0b0' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#b0b0b0' }
                    }
                }
            }
        });
    }

    // Create Heart Rate Variability Chart
    createHRVChart(containerId, data) {
        const canvas = document.getElementById(containerId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts[containerId]) {
            this.charts[containerId].destroy();
        }

        this.charts[containerId] = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels || ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                        label: 'HRV (ms)',
                        data: data.values || [45, 42, 38, 41, 44, 48, 52],
                        borderColor: '#00ff88',
                        backgroundColor: 'rgba(0, 255, 136, 0.1)',
                        fill: true,
                        tension: 0.4
                    },
                    {

                        borderColor: 'rgba(255, 255, 255, 0.3)',
                        borderDash: [5, 5],
                        pointRadius: 0,
                        fill: false
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: { color: '#b0b0b0' }
                    }
                },
                scales: {
                    y: {
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#b0b0b0' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#b0b0b0' }
                    }
                }
            }
        });
    }

    // Create Sleep Quality Chart
    createSleepChart(containerId, data) {
        const canvas = document.getElementById(containerId);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        if (this.charts[containerId]) {
            this.charts[containerId].destroy();
        }

        this.charts[containerId] = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.labels || ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Hours of Sleep',
                    data: data.values || [7.5, 6, 8, 7, 6.5, 9, 8.5],
                    backgroundColor: function(context) {
                        const value = context.dataset.data[context.dataIndex];
                        return value >= 7 ? '#00ff88' : '#ff4444';
                    },
                    borderRadius: 5
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 12,
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#b0b0b0' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#b0b0b0' }
                    }
                }
            }
        });
    }

    // Helper function to get colors for multiple datasets
    getColor(index) {
        const colors = ['#00ff88', '#4169e1', '#8a2be2', '#ff4444', '#ffa500', '#ff69b4'];
        return colors[index % colors.length];
    }

    // Update all charts with new data
    updateAllCharts(userData) {
        if (userData.workouts) {
            const strengthData = this.calculateStrengthTrend(userData.workouts);
            this.createStrengthChart('strengthChart', strengthData);

            const muscleData = this.calculateMuscleBalance(userData.workouts);
            this.createMuscleRadarChart('muscleChart', muscleData);

            const volumeData = this.calculateWeeklyVolume(userData.workouts);
            this.createVolumeChart('volumeChart', volumeData);
        }

        if (userData.nutrition) {
            const caloriesData = this.calculateCaloriesTrend(userData.nutrition);
            this.createCaloriesChart('caloriesChart', caloriesData);

            const macroData = this.calculateMacros(userData.nutrition);
            this.createMacroChart('macroChart', macroData);
        }

        if (userData.sleep) {
            this.createSleepChart('sleepChart', { values: userData.sleep });
        }
    }

    // Data calculation helpers
    calculateStrengthTrend(workouts) {
        // Group workouts by week and calculate average strength score
        const weeklyScores = [];
        const labels = [];

        // Implementation would process workouts data
        return {
            labels: labels,
            values: weeklyScores
        };
    }

    calculateMuscleBalance(workouts) {
        const muscles = ['Chest', 'Back', 'Legs', 'Shoulders', 'Arms', 'Core'];
        const values = muscles.map(muscle => {
            // Calculate frequency of each muscle group
            return Math.floor(Math.random() * 30) + 60; // Placeholder
        });

        return {
            labels: muscles,
            values: values,
            target: [80, 80, 80, 80, 80, 80]
        };
    }

    calculateWeeklyVolume(workouts) {
        const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        const volumes = days.map(() => Math.floor(Math.random() * 2000) + 500); // Placeholder

        return {
            labels: days,
            values: volumes
        };
    }

    calculateCaloriesTrend(nutrition) {
        const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        const consumed = days.map(() => Math.floor(Math.random() * 500) + 1800); // Placeholder
        const burned = days.map(() => Math.floor(Math.random() * 400) + 400); // Placeholder

        return {
            labels: days,
            consumed: consumed,
            burned: burned
        };
    }

    calculateMacros(nutrition) {
        // Calculate macro percentages
        return [30, 45, 25]; // Protein, Carbs, Fats percentages
    }

    // Destroy all charts (cleanup)
    destroyAll() {
        Object.values(this.charts).forEach(chart => {
            if (chart) chart.destroy();
        });
        this.charts = {};
    }
}

// Export for use
// Removed module.exports for ESLint compatibility