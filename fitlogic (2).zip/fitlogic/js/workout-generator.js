// Workout Generator with Rule-Based Logic
class WorkoutGenerator {
    constructor() {
        this.exercises = this.loadExercises();
        this.rules = new RuleEngine();
        this.warmupExercises = [
            { name: 'Arm Circles', duration: '30 sec' },
            { name: 'Leg Swings', duration: '30 sec' },
            { name: 'Torso Twists', duration: '30 sec' },
            { name: 'Jumping Jacks', duration: '30 sec' },
            { name: 'High Knees', duration: '30 sec' },
            { name: 'Butt Kicks', duration: '30 sec' },
            { name: 'Walking Lunges', duration: '30 sec' },
            { name: 'Shoulder Rolls', duration: '30 sec' }
        ];
        this.cooldownExercises = [
            { name: 'Quad Stretch', duration: '30 sec each' },
            { name: 'Hamstring Stretch', duration: '30 sec each' },
            { name: 'Chest Stretch', duration: '30 sec' },
            { name: 'Child\'s Pose', duration: '60 sec' },
            { name: 'Tricep Stretch', duration: '30 sec each' },
            { name: 'Cat-Cow Stretch', duration: '45 sec' },
            { name: 'Seated Forward Fold', duration: '45 sec' },
            { name: 'Hip Flexor Stretch', duration: '30 sec each' }
        ];
    }

    loadExercises() {
        return {
            chest: [
                { name: 'Barbell Bench Press', sets: 4, reps: '8-12', rest: 90, equipment: 'barbell' },
                { name: 'Dumbbell Flyes', sets: 3, reps: '10-15', rest: 60, equipment: 'dumbbell' },
                { name: 'Push-ups', sets: 3, reps: 'To failure', rest: 60, equipment: 'bodyweight' },
                { name: 'Incline Dumbbell Press', sets: 4, reps: '8-12', rest: 90, equipment: 'dumbbell' },
                { name: 'Cable Crossovers', sets: 3, reps: '12-15', rest: 60, equipment: 'cable' }
            ],
            back: [
                { name: 'Pull-ups', sets: 3, reps: '8-12', rest: 90, equipment: 'bodyweight' },
                { name: 'Barbell Rows', sets: 4, reps: '8-10', rest: 90, equipment: 'barbell' },
                { name: 'Lat Pulldowns', sets: 3, reps: '10-12', rest: 60, equipment: 'cable' },
                { name: 'Deadlifts', sets: 3, reps: '5-8', rest: 120, equipment: 'barbell' },
                { name: 'Face Pulls', sets: 3, reps: '15-20', rest: 45, equipment: 'cable' }
            ],
            legs: [
                { name: 'Squats', sets: 4, reps: '8-10', rest: 120, equipment: 'barbell' },
                { name: 'Romanian Deadlifts', sets: 3, reps: '10-12', rest: 90, equipment: 'dumbbell' },
                { name: 'Leg Press', sets: 3, reps: '12-15', rest: 60, equipment: 'machine' },
                { name: 'Lunges', sets: 3, reps: '12 each', rest: 60, equipment: 'dumbbell' },
                { name: 'Calf Raises', sets: 4, reps: '15-20', rest: 45, equipment: 'bodyweight' }
            ],
            shoulders: [
                { name: 'Overhead Press', sets: 4, reps: '8-10', rest: 90, equipment: 'barbell' },
                { name: 'Lateral Raises', sets: 3, reps: '12-15', rest: 45, equipment: 'dumbbell' },
                { name: 'Front Raises', sets: 3, reps: '12-15', rest: 45, equipment: 'dumbbell' },
                { name: 'Rear Delt Flyes', sets: 3, reps: '15-20', rest: 45, equipment: 'dumbbell' },
                { name: 'Upright Rows', sets: 3, reps: '10-12', rest: 60, equipment: 'barbell' }
            ],
            arms: [
                { name: 'Barbell Curls', sets: 3, reps: '8-12', rest: 60, equipment: 'barbell' },
                { name: 'Tricep Pushdowns', sets: 3, reps: '12-15', rest: 60, equipment: 'cable' },
                { name: 'Hammer Curls', sets: 3, reps: '10-12', rest: 45, equipment: 'dumbbell' },
                { name: 'Skull Crushers', sets: 3, reps: '10-12', rest: 60, equipment: 'barbell' },
                { name: 'Preacher Curls', sets: 3, reps: '10-15', rest: 45, equipment: 'dumbbell' }
            ],
            core: [
                { name: 'Planks', sets: 3, reps: '60 sec', rest: 30, equipment: 'bodyweight' },
                { name: 'Crunches', sets: 3, reps: '20', rest: 30, equipment: 'bodyweight' },
                { name: 'Russian Twists', sets: 3, reps: '20', rest: 30, equipment: 'bodyweight' },
                { name: 'Leg Raises', sets: 3, reps: '15', rest: 30, equipment: 'bodyweight' },
                { name: 'Mountain Climbers', sets: 3, reps: '30 sec', rest: 30, equipment: 'bodyweight' }
            ],
            cardio: [
                { name: 'Running', duration: '20 min', intensity: 'Moderate' },
                { name: 'Cycling', duration: '25 min', intensity: 'Moderate' },
                { name: 'Jump Rope', duration: '15 min', intensity: 'High' },
                { name: 'Rowing', duration: '20 min', intensity: 'Moderate' },
                { name: 'Stair Climber', duration: '15 min', intensity: 'High' }
            ]
        };
    }

    generateWorkout(input) {
        const timeAvailable = input.timeAvailable || 30;
        const sleep = input.sleep || 7;
        const stress = input.stress || 5;
        const injury = input.injury || null;
        const equipment = input.equipment || [];
        const preferences = input.preferences || [];
        const lastWorkouts = input.lastWorkouts || [];

        // Get rule-based decisions
        const decisions = this.rules.evaluate({
            sleep: sleep,
            stress: stress,
            injury: injury,
            preferences: preferences,
            timeAvailable: timeAvailable
        }, lastWorkouts);

        // Adjust based on decisions
        const intensityModifier = this.getIntensityModifier(decisions);
        const focusMuscles = this.getFocusMuscles(decisions, lastWorkouts, preferences);

        // Generate workout
        let workout = {
            warmup: this.generateWarmup(timeAvailable, intensityModifier),
            mainExercises: this.generateMainExercises(focusMuscles, timeAvailable, intensityModifier, equipment),
            cooldown: this.generateCooldown(timeAvailable),
            cardio: this.generateCardio(timeAvailable, intensityModifier, preferences),
            restTimes: this.getRestTimes(intensityModifier),
            notes: decisions.filter(function(d) { return d.type === 'adjustment'; }).map(function(d) { return d.message; })
        };

        // Add injury modifications if needed
        if (injury) {
            workout = this.modifyForInjury(workout, injury);
        }

        return {
            warmup: workout.warmup,
            mainExercises: workout.mainExercises,
            cooldown: workout.cooldown,
            cardio: workout.cardio,
            restTimes: workout.restTimes,
            notes: workout.notes,
            decisions: decisions,
            intensity: this.calculateIntensity(intensityModifier),
            estimatedDuration: this.calculateDuration(workout)
        };
    }

    getIntensityModifier(decisions) {
        let modifier = 1.0;
        decisions.forEach(function(decision) {
            if (decision.intensity) {
                modifier *= (decision.intensity / 100);
            }
        });
        return Math.max(0.4, Math.min(1.0, modifier));
    }

    getFocusMuscles(decisions, lastWorkouts, preferences) {
        let focusToMuscles = {
            'fullbody': ['chest', 'back', 'legs', 'shoulders', 'arms', 'core'],
            'upper': ['chest', 'back', 'shoulders', 'arms'],
            'lower': ['legs', 'core'],
            'push': ['chest', 'shoulders', 'triceps'],
            'pull': ['back', 'biceps', 'core'],
            'cardio': ['legs', 'core']
        };

        if (preferences && preferences.length > 0) {
            let focus = preferences[0];
            if (focusToMuscles[focus]) {
                return focusToMuscles[focus].slice(0, 3);
            }
        }

        let muscles = ['chest', 'back', 'legs', 'shoulders', 'arms', 'core'];

        decisions.forEach(function(decision) {
            if (decision.type === 'warning' && decision.message && decision.message.indexOf('Chest') !== -1) {
                muscles = muscles.filter(function(m) { return m !== 'chest'; });
                muscles.push('back', 'core');
            }
        });

        if (lastWorkouts && lastWorkouts.length > 0 && lastWorkouts[0] && lastWorkouts[0].mainExercises) {
            try {
                let lastMuscles = lastWorkouts[0].mainExercises.map(function(e) { return e.muscleGroup; });
                muscles = muscles.filter(function(m) { return lastMuscles.indexOf(m) === -1; });
            } catch (e) {
                if (typeof showToast !== 'undefined') showToast('Using default muscles', 'info');
            }
        }

        return muscles.slice(0, 3);
    }

    generateWarmup(time, intensity) {
        let shuffled = this.warmupExercises.slice().sort(function() { return 0.5 - Math.random(); });
        return shuffled.slice(0, Math.min(6, shuffled.length));
    }

    generateMainExercises(muscles, time, intensity, equipment) {
        let exercises = [];
        let exercisesPerMuscle = Math.max(1, Math.floor(time / (15 * muscles.length)));

        let availableEquipment = equipment.length > 0 ? equipment.concat(['bodyweight']) : ['bodyweight'];

        let self = this;
        muscles.forEach(function(muscle) {
            if (!self.exercises[muscle]) return;

            let available = self.exercises[muscle].filter(function(ex) {
                return availableEquipment.indexOf(ex.equipment) !== -1;
            });

            let toUse = available.length > 0 ? available : self.exercises[muscle].filter(function(ex) { return ex.equipment === 'bodyweight'; });

            for (let i = 0; i < exercisesPerMuscle; i++) {
                if (toUse.length > 0) {
                    let exIndex = i % toUse.length;
                    let ex = toUse[exIndex];
                    exercises.push({
                        name: ex.name,
                        sets: Math.max(1, Math.floor(ex.sets * intensity)),
                        reps: ex.reps,
                        rest: Math.floor(ex.rest * (intensity < 0.8 ? 1.2 : 1)),
                        equipment: ex.equipment,
                        muscleGroup: muscle
                    });
                }
            }
        });

        return exercises;
    }

    generateCooldown(time) {
        let shuffled = this.cooldownExercises.slice().sort(function() { return 0.5 - Math.random(); });
        return shuffled.slice(0, Math.min(6, shuffled.length));
    }

    generateCardio(time, intensity, preferences) {
        const focusPref = (preferences && preferences.length > 0) ? preferences[0] : null;

        if (focusPref === 'cardio' || time >= 45) {
            const cardioTime = Math.min(20, Math.floor(time * 0.3));
            const options = this.exercises.cardio;
            return {
                name: options[Math.floor(Math.random() * options.length)].name,
                duration: cardioTime + ' min',
                intensity: 'High'
            };
        } else if (time >= 30) {
            const cardioTime = Math.min(15, Math.floor(time * 0.2));
            const options = this.exercises.cardio;
            return {
                name: options[Math.floor(Math.random() * options.length)].name,
                duration: cardioTime + ' min',
                intensity: 'Moderate'
            };
        }

        return null;
    }

    getRestTimes(intensity) {
        return {
            compound: Math.floor(90 * (intensity < 0.8 ? 1.2 : 1)),
            isolation: Math.floor(60 * (intensity < 0.8 ? 1.2 : 1)),
            cardio: 30
        };
    }

    modifyForInjury(workout, injury) {
        let injuryModifications = {
            shoulder: ['Overhead Press', 'Upright Rows'],
            knee: ['Squats', 'Lunges'],
            back: ['Deadlifts', 'Barbell Rows'],
            wrist: ['Push-ups', 'Barbell exercises']
        };

        let avoid = injuryModifications[injury.type] || [];

        workout.mainExercises = workout.mainExercises.filter(function(ex) {
            return avoid.indexOf(ex.name) === -1;
        });

        if (!workout.notes) workout.notes = [];
        workout.notes.push('Modified for ' + injury.type + ' injury - avoid heavy loading');

        return workout;
    }

    calculateIntensity(modifier) {
        if (modifier >= 0.9) return 'High';
        if (modifier >= 0.7) return 'Moderate';
        return 'Low';
    }

    calculateDuration(workout) {
        let total = 0;
        total += workout.warmup.length * 30;
        workout.mainExercises.forEach(function(ex) {
            total += ex.sets * (ex.rest + 45);
        });
        total += workout.cooldown.length * 45;
        if (workout.cardio && workout.cardio.duration) {
            total += parseInt(workout.cardio.duration) * 60;
        }
        return Math.round(total / 60);
    }

    // Save workout to SQLite database with localStorage fallback
    saveWorkout(workout) {
        let self = this;

        // Try to save to SQLite first
        if (typeof fitlogicDB !== 'undefined') {
            fitlogicDB.init().then(function() {
                return fitlogicDB.saveWorkout({
                    date: new Date().toISOString(),
                    id: Date.now(),
                    warmup: workout.warmup,
                    mainExercises: workout.mainExercises,
                    cooldown: workout.cooldown,
                    cardio: workout.cardio,
                    intensity: workout.intensity,
                    estimatedDuration: workout.estimatedDuration,
                    completed: workout.completed || false,
                    completedAt: workout.completedAt || null
                });
            }).then(function() {
                self.updateFitnessScore();
            }).catch(function(err) {
                if (typeof showToast !== 'undefined') showToast('Using localStorage fallback (SQLite error)', 'info');
                self.saveWorkoutLocalStorage(workout);
            });
        } else {
            // Fallback to localStorage if SQLite not available
            self.saveWorkoutLocalStorage(workout);
        }
    }

    // Fallback localStorage method
    saveWorkoutLocalStorage(workout) {
        let workouts = JSON.parse(localStorage.getItem('fitlogic_workouts') || '[]');
        workouts.push({
            date: new Date().toISOString(),
            id: Date.now()
        });

        if (workout.warmup) workouts[workouts.length - 1].warmup = workout.warmup;
        if (workout.mainExercises) workouts[workouts.length - 1].mainExercises = workout.mainExercises;
        if (workout.cooldown) workouts[workouts.length - 1].cooldown = workout.cooldown;
        if (workout.cardio) workouts[workouts.length - 1].cardio = workout.cardio;
        if (workout.intensity) workouts[workouts.length - 1].intensity = workout.intensity;
        if (workout.estimatedDuration) workouts[workouts.length - 1].estimatedDuration = workout.estimatedDuration;
        if (workout.focus) workouts[workouts.length - 1].focus = workout.focus;

        localStorage.setItem('fitlogic_workouts', JSON.stringify(workouts));
        this.updateFitnessScore();
    }

    // Get workouts from SQLite or localStorage
    getWorkouts(callback) {
        let self = this;

        if (typeof fitlogicDB !== 'undefined' && fitlogicDB.isInitialized) {
            fitlogicDB.getWorkouts(1000).then(function(workouts) {
                if (callback) callback(workouts);
            }).catch(function(err) {
                if (typeof showToast !== 'undefined') showToast('Using localStorage workouts', 'info');
                let workouts = JSON.parse(localStorage.getItem('fitlogic_workouts') || '[]');
                if (callback) callback(workouts);
            });
        } else {
            // Fallback to localStorage
            let workouts = JSON.parse(localStorage.getItem('fitlogic_workouts') || '[]');
            if (callback) callback(workouts);
        }
    }

    updateFitnessScore() {
        let self = this;

        // Try SQLite first, fallback to localStorage
        let getWorkoutsFn = function(workouts) {
            let score = self.rules.calculateFitnessScore(workouts);
            localStorage.setItem('fitlogic_score', score);
            if (typeof window !== 'undefined') {
                window.dispatchEvent(new CustomEvent('fitnessScoreUpdated', { detail: score }));
            }
        };

        if (typeof fitlogicDB !== 'undefined' && fitlogicDB.isInitialized) {
            fitlogicDB.getWorkouts(1000).then(getWorkoutsFn).catch(function() {
                let workouts = JSON.parse(localStorage.getItem('fitlogic_workouts') || '[]');
                getWorkoutsFn(workouts);
            });
        } else {
            let workouts = JSON.parse(localStorage.getItem('fitlogic_workouts') || '[]');
            getWorkoutsFn(workouts);
        }
    }

    getAlternativeExercise(exerciseName, muscleGroup) {
        let exercises = this.exercises[muscleGroup] || [];
        let alternatives = exercises.filter(function(ex) { return ex.name !== exerciseName; });
        if (alternatives.length > 0) {
            return alternatives[Math.floor(Math.random() * alternatives.length)];
        }
        return null;
    }

    getAlternativeWarmupExercise(exerciseName) {
        let alternatives = this.warmupExercises.filter(function(ex) { return ex.name !== exerciseName; });
        if (alternatives.length > 0) {
            return alternatives[Math.floor(Math.random() * alternatives.length)];
        }
        return null;
    }

    getAlternativeCooldownExercise(exerciseName) {
        let alternatives = this.cooldownExercises.filter(function(ex) { return ex.name !== exerciseName; });
        if (alternatives.length > 0) {
            return alternatives[Math.floor(Math.random() * alternatives.length)];
        }
        return null;
    }

    generateNewWorkout(input) {
        return this.generateWorkout(input);
    }
}

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = WorkoutGenerator;
}

// Expose to global scope for browser
if (typeof window !== 'undefined') {
    window.WorkoutGenerator = WorkoutGenerator;
}