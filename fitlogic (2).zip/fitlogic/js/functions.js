// Global Functions for FitLogic
// This file contains all shared functions that need to be globally accessible

// Legacy settings functions kept for compatibility
function openSettings() {
    window.location.href = 'settings.html';
}

function createSettingsModal() {
    const modalHtml = `
    <div class="modal fade" id="settingsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content glass-card">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-cog"></i> Settings</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="settings-section">
                        <h6>Profile Settings</h6>
                        <div class="mb-3">
                            <label>Name</label>
                            <input type="text" class="form-control" id="settingsName" placeholder="Your name">
                        </div>
                        <div class="mb-3">
                            <label>Goal</label>
                            <select class="form-control" id="settingsGoal">
                                <option value="Weight Loss">Weight Loss</option>
                                <option value="Muscle Gain">Muscle Gain</option>
                                <option value="Strength">Strength</option>
                                <option value="General Fitness">General Fitness</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="settings-section">
                        <h6>Workout Preferences</h6>
                        <div class="mb-3">
                            <label>Default Workout Duration</label>
                            <select class="form-control" id="settingsDuration">
                                <option value="15">15 minutes</option>
                                <option value="30" selected>30 minutes</option>
                                <option value="45">45 minutes</option>
                                <option value="60">60 minutes</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label>Preferred Focus</label>
                            <select class="form-control" id="settingsFocus">
                                <option value="fullbody">Full Body</option>
                                <option value="upper">Upper Body</option>
                                <option value="lower">Lower Body</option>
                                <option value="push">Push</option>
                                <option value="pull">Pull</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="settings-section">
                        <h6>Data Management</h6>
                        <button class="btn btn-outline-danger me-2" onclick="clearAllData()">
                            <i class="fas fa-trash"></i> Clear All Data
                        </button>
                        <button class="btn btn-outline-neon" onclick="exportData()">
                            <i class="fas fa-download"></i> Export Data
                        </button>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-neon-glow" onclick="saveSettings()">Save Changes</button>
                </div>
            </div>
        </div>
    </div>
    `;

    // Add modal to body
    const div = document.createElement('div');
    div.innerHTML = modalHtml;
    document.body.appendChild(div);

    // Show the modal
    setTimeout(() => {
        const modal = document.getElementById('settingsModal');
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();

        // Load current settings
        loadCurrentSettings();
    }, 100);
}

function loadCurrentSettings() {
    const user = JSON.parse(localStorage.getItem('fitlogic_user') || '{}');
    const prefs = JSON.parse(localStorage.getItem('fitlogic_preferences') || '{}');

    const nameInput = document.getElementById('settingsName');
    const goalSelect = document.getElementById('settingsGoal');
    const durationSelect = document.getElementById('settingsDuration');
    const focusSelect = document.getElementById('settingsFocus');

    if (nameInput) nameInput.value = user.name || '';
    if (goalSelect) goalSelect.value = user.goal || 'Muscle Gain';
    if (durationSelect) durationSelect.value = prefs.defaultDuration || '30';
    if (focusSelect) focusSelect.value = prefs.focus || 'fullbody';
}

function saveSettings() {
    const nameInput = document.getElementById('settingsName');
    const goalSelect = document.getElementById('settingsGoal');
    const durationSelect = document.getElementById('settingsDuration');
    const focusSelect = document.getElementById('settingsFocus');

    const name = nameInput ? nameInput.value : '';
    const goal = goalSelect ? goalSelect.value : '';
    const duration = durationSelect ? durationSelect.value : '30';
    const focus = focusSelect ? focusSelect.value : 'fullbody';

    // Save user data
    const user = JSON.parse(localStorage.getItem('fitlogic_user') || '{}');
    user.name = name;
    user.goal = goal;
    localStorage.setItem('fitlogic_user', JSON.stringify(user));

    // Save preferences
    const prefs = JSON.parse(localStorage.getItem('fitlogic_preferences') || '{}');
    prefs.defaultDuration = duration;
    prefs.focus = focus;
    localStorage.setItem('fitlogic_preferences', JSON.stringify(prefs));

    // Close modal
    const modal = document.getElementById('settingsModal');
    if (modal) {
        const bsModal = bootstrap.Modal.getInstance(modal);
        if (bsModal) bsModal.hide();
    }

    // Show success message
    showToast('Settings saved successfully!');

    // Refresh page to apply changes
    setTimeout(() => location.reload(), 500);
}

function clearAllData() {
    if (confirm('Are you sure you want to clear all your data? This cannot be undone.')) {
        localStorage.clear();
        showToast('All data cleared. Refreshing...');
        setTimeout(() => location.reload(), 1000);
    }
}

function exportData() {
    const data = {
        user: localStorage.getItem('fitlogic_user'),
        workouts: localStorage.getItem('fitlogic_workouts'),
        meals: localStorage.getItem('fitlogic_meals'),
        preferences: localStorage.getItem('fitlogic_preferences'),
        score: localStorage.getItem('fitlogic_score'),
        chatHistory: localStorage.getItem('fitlogic_chat_history'),
        exportDate: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'fitlogic-data-' + new Date().toISOString().split('T')[0] + '.json';
    link.click();
    URL.revokeObjectURL(url);

    showToast('Data exported successfully!');
}

// Toast notification function
function showToast(message, type = 'success') {
    // Remove existing toasts
    document.querySelectorAll('.sync-toast').forEach(t => t.remove());

    const toast = document.createElement('div');
    toast.className = `sync-toast ${type}`;

    let icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'info') icon = 'info-circle';

    toast.innerHTML = `<i class="fas fa-${icon}"></i><span>${message}</span>`;
    document.body.appendChild(toast);

    // Auto remove
    setTimeout(() => {
        toast.classList.add('fade-out');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function logout() {
    localStorage.removeItem('fitlogic_user');
    showToast('Logged out successfully!');
    window.location.href = 'index.html';
}

// Export all functions to window - ensuring global availability for onclick handlers
window.openSettings = openSettings;
window.createSettingsModal = createSettingsModal;
window.saveSettings = saveSettings;
window.clearAllData = clearAllData;
window.exportData = exportData;
window.showToast = showToast;
window.logout = logout;